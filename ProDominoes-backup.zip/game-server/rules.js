/* ============================================================
   ЯДРО ИГРЫ — правила домино и ничего кроме них.

   Здесь нет React, нет экрана, нет звука и нет таймеров.
   Файл отвечает на один вопрос: «вот положение партии и вот
   чей-то ход — какое положение получилось?»

   Тем же файлом пользуется экран и будет пользоваться сервер,
   поэтому судья у всех игроков один и тот же.
   ============================================================ */

/* ---------- стол ---------- */
// сколько игроков, сколько костей в базаре и сколько из базара трогать нельзя
const TABLES = {
  "2x2": { seats: 4, bazaar: 0, locked: 0 },
  heads: { seats: 2, bazaar: 14, locked: 2 },
  three: { seats: 3, bazaar: 7, locked: 1 },
};

// в парной игре места 0 и 2 — одна команда, 1 и 3 — другая
const SEAT_TEAM = [0, 1, 0, 1];
const OPEN_AT = 13; // пока не набрал 13 — очки лежат в наборе, а не на табло

/* ---------- кости ---------- */
const key = (t) => `${t[0]}-${t[1]}`;
const pips = (t) => t[0] + t[1];
const sumPips = (h) => {
  if (h.length === 1 && h[0][0] === 0 && h[0][1] === 0) return 10;
  return h.reduce((s, t) => s + t[0] + t[1], 0);
};
const isDouble = (t) => t[0] === t[1];

function makeDeck() {
  const d = [];
  for (let i = 0; i <= 6; i++) for (let j = i; j <= 6; j++) d.push([i, j]);
  return d;
}

// rng можно передать свой — тогда раздача повторяется в точности.
// это нужно серверу: он раздаёт по семени и может воспроизвести партию
function shuffle(a, rng = Math.random) {
  const x = a.slice();
  for (let i = x.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [x[i], x[j]] = [x[j], x[i]];
  }
  return x;
}

/* ---------- раздача ---------- */
// раздача-«пустышка» не годится: пять дублей на руках нельзя,
// пять костей одной масти без её дубля — тоже, шесть одной масти — никогда
function handOk(h) {
  if (h.filter(isDouble).length >= 5) return false;
  const cnt = Array(7).fill(0);
  for (const t of h) {
    cnt[t[0]]++;
    if (t[1] !== t[0]) cnt[t[1]]++;
  }
  for (let s = 0; s <= 6; s++) {
    if (cnt[s] >= 6) return false;
    if (cnt[s] === 5 && !h.some((t) => t[0] === s && t[1] === s)) return false;
  }
  return true;
}

function dealFor(mode, rng = Math.random) {
  const t = TABLES[mode];
  let last = null;
  for (let attempt = 0; attempt < 400; attempt++) {
    const d = shuffle(makeDeck(), rng);
    const h = [];
    for (let i = 0; i < t.seats; i++) h.push(d.slice(i * 7, i * 7 + 7));
    last = { h, rest: d.slice(t.seats * 7) };
    if (h.every(handOk)) return last;
  }
  return last;
}

// если нужного дубля нет ни у кого (лежит в базаре) — заходит младший дубль, иначе младшая кость
function lowestStarter(h) {
  let best = -1,
    bestVal = 99;
  for (let i = 0; i < h.length; i++)
    for (const t of h[i]) {
      const v = isDouble(t) ? t[0] : 10 + pips(t);
      if (v < bestVal) {
        bestVal = v;
        best = i;
      }
    }
  return best;
}

function handQuality(h) {
  const cnt = Array(7).fill(0);
  h.forEach((t) => {
    cnt[t[0]]++;
    if (t[1] !== t[0]) cnt[t[1]]++;
  });
  return Math.max(...cnt) * 3 + h.filter(isDouble).length * 2 - sumPips(h) / 12;
}

/* ---------- ходы ---------- */
// forced: номер дубля, которым обязаны зайти в первом круге партии (или null)
function legalPlays(hand, chain, forced) {
  if (chain.length === 0) {
    const src =
      forced === null || forced === undefined
        ? hand
        : hand.filter((t) => t[0] === forced && t[1] === forced);
    return src.map((t) => ({ tile: t, sides: ["right"] }));
  }
  const L = chain[0].d[0];
  const R = chain[chain.length - 1].d[1];
  const out = [];
  for (const t of hand) {
    const sides = [];
    if (t[0] === L || t[1] === L) sides.push("left");
    if (t[0] === R || t[1] === R) sides.push("right");
    if (sides.length) out.push({ tile: t, sides });
  }
  return out;
}

function orient(tile, side, chain) {
  if (!chain.length) return [tile[0], tile[1]];
  if (side === "left") {
    const L = chain[0].d[0];
    return tile[1] === L ? [tile[0], tile[1]] : [tile[1], tile[0]];
  }
  const R = chain[chain.length - 1].d[1];
  return tile[0] === R ? [tile[0], tile[1]] : [tile[1], tile[0]];
}


/* Оценка хода. Веса подобраны прогонами по 20 000 партий на общих
   раздачах: связка «оба конца одной масти» + сброс дублей даёт
   +4 пункта к победам против прежней эвристики.

   Что считаем:
     — сбрасываем тяжёлое, чтобы не остаться с балластом при рыбе;
     — дубли уходят первыми: их некуда пристроить потом;
     — держим кости под оба конца, чтобы не сесть в тупик;
     — сводим оба конца к одной масти: соперник обязан её иметь,
       иначе пас. Тем ценнее, чем больше этой масти у нас на руках. */
function moveScore(tile, side, chain, hand) {
  const d = orient(tile, side, chain);
  const newEnd = side === "left" ? d[0] : d[1];
  const otherEnd = chain.length
    ? side === "left"
      ? chain[chain.length - 1].d[1]
      : chain[0].d[0]
    : side === "left"
      ? d[1]
      : d[0];
  const rest = hand.filter((t) => key(t) !== key(tile));
  if (rest.length === 0) return 1e6; // выход — всегда лучший ход
  const cNew = rest.filter((t) => t[0] === newEnd || t[1] === newEnd).length;
  const cOther = rest.filter((t) => t[0] === otherEnd || t[1] === otherEnd).length;
  let s = pips(tile) * 0.7 + (isDouble(tile) ? 14 : 0) + (cNew + cOther) * 4.5;
  if (newEnd === otherEnd) s += 16 + cNew * 6;
  return s;
}


/* skill: 0 — новичок, 1 — предел. Управляет только разбросом:
   чем ниже мастерство, тем чаще бот берёт не лучший ход.
   Размах 70 выставлен так, чтобы шкала действительно читалась —
   при прежних 5 разницы между 0.55 и 0.85 не было вовсе. */
function aiPick(hand, chain, forced, rng = Math.random, skill = 0.55) {
  const opts = legalPlays(hand, chain, forced);
  if (!opts.length) return null;
  if (hand.length === 1) return { tile: opts[0].tile, side: opts[0].sides[0] };
  const noise = (1 - Math.max(0, Math.min(1, skill))) * 70;
  let best = null,
    bestScore = -1e9;
  for (const o of opts)
    for (const side of o.sides) {
      const s = moveScore(o.tile, side, chain, hand) + rng() * noise;
      if (s > bestScore) {
        bestScore = s;
        best = { tile: o.tile, side };
      }
    }
  return best;
}

/* ============================================================
   ПОЛОЖЕНИЕ ПАРТИИ И ХОДЫ

   Всё ниже — чистые функции. Они ничего не меняют у себя внутри:
   получают положение и возвращают новое. Старое остаётся целым,
   поэтому партию можно записать, переслать и воспроизвести.
   ============================================================ */

const teamOf = (mode, seat) => (mode === "2x2" ? SEAT_TEAM[seat] : seat);

/**
 * Каким дублем заходят в партии.
 * Партия 1 — 1:1, партия 2 — 2:2 … партия 6 — 6:6, седьмая — 0:0.
 * Если нужного дубля нет ни у кого на руках (лежит в закрытом базаре),
 * заходят следующим по кругу: 1:1 → 2:2 → 3:3 … → 6:6 → 0:0.
 * Совсем без дублей на руках заходит младшая кость.
 */
function pickOpening(hands, gameNo) {
  const wanted = gameNo % 7;
  for (let i = 0; i < 7; i++) {
    const d = (wanted + i) % 7;
    const seat = hands.findIndex((x) => x.some((k) => k[0] === d && k[1] === d));
    if (seat >= 0) return { dbl: d, opener: seat, wanted, shifted: d !== wanted };
  }
  return { dbl: null, opener: lowestStarter(hands), wanted, shifted: true };
}

/** Следующий круг той же партии: счёт и набор сохраняются. */
function nextRound(state, { rng = Math.random, starter = null } = {}) {
  const { h, rest } = dealFor(state.mode, rng);
  const go = starter === null ? state.starter : starter;
  return {
    ...state,
    hands: h,
    bazaar: rest,
    chain: [],
    turn: go,
    starter: go,
    passes: 0,
    firstRound: false,
    opening: null,
    phase: "playing",
    result: null,
  };
}

/** Экранное ядро: руки, цепь, ход, счёт — одно положение, без ручной склейки. */
function emptyCore() {
  return {
    hands: [[], [], [], []],
    chain: [],
    turn: 0,
    scores: [0, 0],
    bank: [0, 0],
    bazaar: [],
    passes: 0,
    starter: 0,
    firstRound: true,
    opening: 1,
    target: 21,
    mode: "heads",
    seats: 2,
    locked: 2,
    fishPot: 0,
    fishWaitOpen: false,
    lastPlay: null,
  };
}

/** Сколько костей из базара ещё можно взять. */
const drawable = (state) => Math.max(0, state.bazaar.length - state.locked);

/** Какой дубль обязателен прямо сейчас (или null). */
const forcedNow = (state) =>
  state.firstRound && state.chain.length === 0 ? state.opening : null;

/** Что может сделать игрок: список костей и сторон. */
function movesFor(state, seat) {
  if (state.phase !== "playing" || state.turn !== seat) return [];
  return legalPlays(state.hands[seat], state.chain, forcedNow(state));
}

/* ---------- подсчёт круга ---------- */
function closeRound(state, winner) {
  const { mode, seats, hands } = state;
  const gof = (i) => teamOf(mode, i);
  const gCount = state.scores.length;

  let winG = winner !== null ? gof(winner) : null;
  if (winG === null) {
    // рыба: очки — у кого меньше на руках; ход следующего круга — у того, кто закрыл стол
    const tot = Array(gCount).fill(0);
    for (let i = 0; i < seats; i++) tot[gof(i)] += sumPips(hands[i]);
    let m = 0;
    for (let g = 1; g < gCount; g++) if (tot[g] < tot[m]) m = g;
    const fishBy = Number.isInteger(state.lastPlay?.seat) ? state.lastPlay.seat : state.turn;
    if (tot.filter((v) => v === tot[m]).length > 1) {
      let pot = 0;
      for (let i = 0; i < seats; i++) pot += sumPips(hands[i]);
      const anyoneOpen = (state.scores || []).some((s) => (s || 0) > 0);
      const fishPot = (state.fishPot || 0) + pot;
      return {
        ...state,
        fishPot,
        fishWaitOpen: anyoneOpen ? false : true,
        phase: "roundOver",
        starter: fishBy,
        result: {
          tie: true,
          fishHold: true,
          pts: pot,
          fishPot,
          fishWaitOpen: anyoneOpen ? false : true,
          winner: null,
          winG: null,
          fishBy,
          hands,
          scores: state.scores,
          bank: state.bank,
        },
      };
    }
    winG = m;
  }

  // очки, оставшиеся на руках у соперников, записываются победителю круга
  let pts = 0;
  for (let i = 0; i < seats; i++) if (gof(i) !== winG) pts += sumPips(hands[i]);

  const scores = state.scores.slice();
  const bank = state.bank.slice();
  let fishPot = state.fishPot || 0;
  let fishWaitOpen = !!state.fishWaitOpen;
  const wasOpen = (scores[winG] || 0) > 0;
  let openedNow = false;
  let burned = false;
  let potTaken = 0;
  const takePot = () => {
    if (!fishPot) return;
    potTaken = fishPot;
    fishPot = 0;
    fishWaitOpen = false;
  };

  /* Рыба не помогает набрать 13. Сначала пишем кости круга.
     Горшок отдаём только тому, кто уже на табло или только что открылся от 13. */
  if (wasOpen) {
    scores[winG] += pts;
    takePot();
    if (potTaken) scores[winG] += potTaken;
  } else {
    bank[winG] = (bank[winG] || 0) + pts;
    if (bank[winG] >= OPEN_AT) {
      scores[winG] = bank[winG];
      bank[winG] = 0;
      openedNow = true;
      takePot();
      if (potTaken) scores[winG] += potTaken;
    }
  }
  // набор меньше 13 сгорает, только когда соперник открылся
  if (openedNow) {
    for (let g = 0; g < gCount; g++) {
      if (g !== winG && (scores[g] || 0) === 0 && (bank[g] || 0) > 0) {
        bank[g] = 0;
        burned = true;
      }
    }
  }

  const nextStarter = winner === null
    ? (Number.isInteger(state.lastPlay?.seat) ? state.lastPlay.seat : state.turn)
    : winner;
  const goal = Number(state.target);
  const need = Number.isFinite(goal) && goal > 0 ? goal : 21;
  const champ = scores.findIndex((v) => Number(v) >= need);
  const base = {
    ...state,
    scores,
    bank,
    fishPot,
    fishWaitOpen,
    starter: nextStarter,
    result: {
      tie: false,
      winner,
      winG,
      pts,
      potTaken,
      pending: !wasOpen && !openedNow,
      openedNow,
      burned,
      hands,
      scores,
      bank,
      fishPot,
    },
  };

  if (champ < 0) return { ...base, phase: "roundOver" };

  // партия взята: сухая, если у всех соперников на табло ноль
  const others = scores.map((_, g) => g).filter((g) => g !== champ);
  const dry = others.every((g) => scores[g] === 0);
  let loserG = others[0];
  for (const g of others) if (scores[g] < scores[loserG]) loserG = g;

  return {
    ...base,
    phase: "gameOver",
    result: { ...base.result, over: true, champ, dry, loserG, points: dry ? 2 : 1 },
  };
}

/* ============================================================
   СУДЬЯ

   reduce(положение, ход) → новое положение.
   Ход, который нарушает правила, не проходит: возвращается то же
   положение и поле error. Именно это и проверяет сервер.
   ============================================================ */
function reduce(state, action) {
  if (!state || !action) return state;
  const deny = (why) => ({ ...state, error: why });

  switch (action.type) {
    case "play": {
      const { seat, tile, side } = action;
      if (state.phase !== "playing") return deny("партия не идёт");
      if (state.turn !== seat) return deny("не ваш ход");
      const opt = legalPlays(state.hands[seat], state.chain, forcedNow(state)).find(
        (p) => key(p.tile) === key(tile)
      );
      if (!opt) return deny("этой костью ходить нельзя");
      const useSide = state.chain.length === 0 ? "right" : side;
      if (!opt.sides.includes(useSide)) return deny("не тот конец");

      const d = orient(tile, useSide, state.chain);
      const chain =
        useSide === "left" ? [{ t: tile, d }, ...state.chain] : [...state.chain, { t: tile, d }];
      const hands = state.hands.map((h, i) =>
        i === seat ? h.filter((x) => key(x) !== key(tile)) : h
      );

      const mid = { ...state, chain, hands, passes: 0, error: null, lastPlay: { seat, tile, side: useSide } };
      // рука опустела — круг взят
      if (hands[seat].length === 0) return closeRound(mid, seat);
      return { ...mid, turn: (seat + 1) % state.seats };
    }

    case "draw": {
      const { seat } = action;
      if (state.phase !== "playing") return deny("партия не идёт");
      if (state.turn !== seat) return deny("не ваш ход");
      if (drawable(state) <= 0) return deny("базар закрыт");
      const i = Number.isInteger(action.index) ? action.index : 0;
      if (i < 0 || i >= drawable(state)) return deny("эта кость закрыта");
      const tile = state.bazaar[i];
      if (!tile) return deny("такой кости в базаре нет");
      return {
        ...state,
        error: null,
        bazaar: state.bazaar.filter((_, k) => k !== i),
        hands: state.hands.map((h, k) => (k === seat ? [...h, tile] : h)),
        lastDraw: { seat, tile },
      };
    }

    case "pass": {
      const { seat } = action;
      if (state.phase !== "playing") return deny("партия не идёт");
      if (state.turn !== seat) return deny("не ваш ход");
      if (movesFor(state, seat).length) return deny("есть чем ходить");
      if (drawable(state) > 0) return deny("сначала возьмите с базара");
      const passes = state.passes + 1;
      // все подряд спасовали — рыба
      if (passes >= state.seats) return closeRound({ ...state, passes, error: null }, null);
      return { ...state, passes, error: null, turn: (seat + 1) % state.seats };
    }

    // сдача: сопернику сразу засчитывается цель партии
    case "surrender": {
      const { seat } = action;
      const gof = (i) => teamOf(state.mode, i);
      const me = gof(seat);
      const foe = state.scores.map((_, g) => g).find((g) => g !== me) ?? 0;
      const scores = state.scores.slice();
      scores[foe] = Math.max(scores[foe] || 0, state.target);
      const others = scores.map((_, g) => g).filter((g) => g !== foe);
      const dry = others.every((g) => scores[g] === 0);
      return {
        ...state,
        scores,
        phase: "gameOver",
        error: null,
        result: {
          tie: false,
          winner: null,
          winG: foe,
          pts: 0,
          surrender: true,
          over: true,
          champ: foe,
          dry,
          loserG: me,
          points: dry ? 2 : 1,
          hands: state.hands,
          scores,
          bank: state.bank,
        },
      };
    }

    case "nextRound":
      if (state.phase !== "roundOver") return deny("круг ещё идёт");
      return nextRound(state, { rng: action.rng, starter: action.starter ?? null });

    default:
      return state;
  }
}

export {
  TABLES, key, pips, isDouble, sumPips,
  shuffle, dealFor, legalPlays, orient, moveScore,
  aiPick, pickOpening, forcedNow, emptyCore, reduce,
  SEAT_TEAM, handQuality,
};

