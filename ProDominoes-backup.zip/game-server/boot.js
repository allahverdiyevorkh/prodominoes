import { readFileSync, writeFileSync, existsSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const dir = dirname(fileURLToPath(import.meta.url));
const appJs = join(dir, "public", "app.js");

const LIVE_INVITED = 'o.on("club:invited",c=>{c?.no&&(l4({text:E("inviteSent",c.from||""),kind:"info"}),o.emit("club:table:join",{no:c.no},f=>{f?.club&&P3(f.club)}))})';
const LIVE_INVITED2 = 'o.on("club:invited",c=>{c?.no&&window.__PD_INVITE&&window.__PD_INVITE({no:c.no,from:c.from||"",join:function(){o.emit("club:table:join",{no:c.no},f=>{f?.club&&P3(f.club)})}})})';
const INVITED_NEW = 'o.on("club:table:starting",c=>{vu(Number(c&&c.sec)||5);s0.current!=="room"&&e("room")}),o.on("club:lobby",c=>{let f=c&&c.room||c;if(!f)return;let m=f.mode==="3"||f.mode==="three"?"three":f.mode==="2x2"?"2x2":"heads";ou(m);if(Number(f.target)>0)a(Number(f.target));if(Number(f.matchTo)>0)Ru(Number(f.matchTo));let k=(f.players||[]).filter(C=>C.id!==o.id).sort((C,U)=>(C.seat??0)-(U.seat??0));qe(["Вы",k[0]&&k[0].name||"Игрок",k[1]&&k[1].name||"",k[2]&&k[2].name||""]);pm.current="public";Fu("public");e("lobby");vu(null)}),o.on("club:match:over",()=>{J3({keep:!1})}),o.on("club:invited",c=>{c&&c.no&&window.__PD_INVITE&&window.__PD_INVITE({no:c.no,from:c.from||"",mode:c.mode||"",join:function(){o.emit("club:table:join",{no:c.no},f=>{f&&f.club&&P3(f.club)})}})})';

const REPLACES = [
  [LIVE_INVITED, INVITED_NEW],
  [LIVE_INVITED2, INVITED_NEW],
  ['pe(!1),Su("idle"),t4==="private"){e("room");return}e("menu")',
   'pe(!1),Su("idle"),t4==="private"||vi.current&&vi.current.name){Fu("private"),e("room");return}e("menu")'],
  ['if(me&&!me.ready)o.emit("room:ready",{ready:!0})',
   'if(me&&!me.ready&&s0.current!=="lobby")o.emit("room:ready",{ready:!0})'],
  ['if(V==="matchOver"||V==="idle"){J3({keep:!1});return}W.tap(),Oi(!0)',
   'if(V==="matchOver"){J3({keep:!1});return}W.tap(),Oi(!0)'],
];

try {
  let raw = readFileSync(appJs, "utf8");
  let n = 0;
  for (const [a, b] of REPLACES) {
    if (raw.includes(a)) {
      raw = raw.split(a).join(b);
      n += 1;
    }
  }
  writeFileSync(appJs, raw);
  console.log("client patched", n);
} catch (e) {
  console.error("client patch failed", e.message);
}

await import("./index.js");
