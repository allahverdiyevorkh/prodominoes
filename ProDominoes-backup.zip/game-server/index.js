/**
 * ProDominoes — шаг 1: сервер комнат
 * Railway: PORT из env, npm start
 *
 * Комнаты в памяти (для 2–50 игроков ок).
 * Шаг 2: клиент шлёт ход → broadcast.
 * Шаг 3: клуб, пароль, 2x2.
 */

import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import { randomBytes, createHash } from "crypto";
import bcrypt from "bcryptjs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";
import { writeFile, readFile, rename } from "fs/promises";

/* Правила игры берём из того же файла, что и клиент. Второй реализации
   быть не должно: она разойдётся с клиентской, и партии начнут ломаться
   на середине. На третьем этапе через reduce пойдут ходы. */
import { TABLES, reduce, dealFor, pickOpening, emptyCore, aiPick } from "./rules.js";

const PORT = Number(process.env.PORT) || 8080;
const __dirname = dirname(fileURLToPath(import.meta.url));
const PUBLIC = join(__dirname, "public");
const SNAP = process.env.SNAP_PATH || join(__dirname, "snapshot.json");
const app = express();
app.use(cors({ origin: true }));
app.use(express.json());
app.use((req, res, next) => {
  const p = String(req.path || "");
  if (p === "/" || p.endsWith(".html") || p.endsWith(".js") || p.endsWith(".css")) {
    res.set("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    res.set("Pragma", "no-cache");
    res.set("Expires", "0");
  }
  next();
});

const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: true, methods: ["GET", "POST"] },
  pingInterval: 20000,
  pingTimeout: 25000,
});

/** @typedef {{ id: string, code: string, hostId: string, mode: string, maxPlayers: number, players: Map<string, Player>, createdAt: number, state: object|null }} Room */
/** @typedef {{ id: string, name: string, seat: number, ready: boolean, socketId: string }} Player */

/** @type {Map<string, Room>} */
const rooms = new Map();
/** socketId → roomId */
const socketRoom = new Map();
/** `${mode}:${target}` → roomId — свободный стол, куда садится второй */
const waiting = new Map();
/** key(name) → Club */
const clubs = new Map();
/** socketId → clubKey */
const socketClub = new Map();
/* Пароль клуба подбирается перебором, если не считать попытки.
   Держим счётчик на адрес: 10 промахов в минуту — дальше отказ. */
const joinTries = new Map(); // ip -> { n, until }

function clientIp(socket) {
  const fwd = socket.handshake?.headers?.["x-forwarded-for"];
  if (fwd) {
    const first = String(Array.isArray(fwd) ? fwd[0] : fwd).split(",")[0].trim();
    if (first) return first;
  }
  return socket.handshake?.address || socket.conn?.remoteAddress || "unknown";
}

function tooManyTries(ip) {
  const now = Date.now();
  const rec = joinTries.get(ip);
  if (!rec || now > rec.until) return false;
  return rec.n >= 10;
}

function noteFail(ip) {
  const now = Date.now();
  const rec = joinTries.get(ip);
  if (!rec || now > rec.until) joinTries.set(ip, { n: 1, until: now + 60_000 });
  else rec.n += 1;
}

setInterval(() => {
  const now = Date.now();
  for (const [ip, rec] of joinTries) {
    if (now > rec.until) joinTries.delete(ip);
  }
}, 60_000).unref();

function publicTable(tb) {
  return {
    no: tb.no,
    mode: tb.mode,
    need: tb.need,
    taken: tb.sitting.length,
    target: tb.target,
    matchTo: tb.matchTo || 1,
    sitting: tb.sitting.map((s) => s.name),
    hostId: tb.hostId,
    opened: !!tb.opened,
  };
}
function publicClub(club) {
  return {
    name: club.name,
    count: club.members.size,
    members: [...club.members.values()].map((m) => ({ id: m.id, name: m.name })),
    tables: (club.tables || []).filter((tb) => !tb.opened).map(publicTable),
    board: club.board || { stats: {}, gold: {}, log: [] },
  };
}
function emptyBoard() {
  return { stats: {}, gold: {}, log: [] };
}
function ensureBoard(club) {
  if (!club.board || typeof club.board !== "object") club.board = emptyBoard();
  if (!club.board.stats) club.board.stats = {};
  if (!club.board.gold) club.board.gold = {};
  if (!club.board.log) club.board.log = [];
  return club.board;
}
function boardPlayer(club, nick) {
  const n = String(nick || "").slice(0, 24);
  if (!n) return;
  const b = ensureBoard(club);
  if (!b.stats[n]) b.stats[n] = { played: 0, wins: 0, dry: 0, years: [] };
  if (b.gold[n] == null) b.gold[n] = 1000;
}
function applyClubResult(club, payload) {
  const winners = (payload.winners || []).map((n) => String(n || "").slice(0, 24)).filter(Boolean);
  const losers = (payload.losers || []).map((n) => String(n || "").slice(0, 24)).filter(Boolean);
  if (!winners.length || !losers.length) return;
  const dry = !!payload.dry;
  const surrender = !!payload.surrender;
  const b = ensureBoard(club);
  for (const n of [...winners, ...losers]) boardPlayer(club, n);
  for (const n of [...winners, ...losers]) b.stats[n].played = (b.stats[n].played || 0) + 1;
  for (const n of winners) {
    b.stats[n].wins = (b.stats[n].wins || 0) + 1;
    if (dry) b.stats[n].dry = (b.stats[n].dry || 0) + 1;
  }
  const stake = surrender ? 50 : 20 + (dry ? 10 : 0);
  let pool = 0;
  for (const n of losers) {
    const have = b.gold[n] ?? 1000;
    const take = Math.min(have, Math.trunc(stake / losers.length) || stake);
    b.gold[n] = have - take;
    pool += take;
  }
  const share = Math.trunc(pool / winners.length);
  let rest = pool - share * winners.length;
  winners.forEach((n, i) => {
    b.gold[n] = (b.gold[n] ?? 1000) + share + (i < rest ? 1 : 0);
  });
  b.log = [{ t: Date.now(), winners, losers, dry, surrender, stake: pool }, ...(b.log || [])].slice(0, 40);
}
function needClubAccount(payload) {
  const email = String(payload.email || "").trim().toLowerCase();
  if (!mailOk(email)) return "need_reg";
  return null;
}
function normClubName(name) {
  return String(name || "")
    .trim()
    .replace(/[\u2018\u2019\u201A\uFF07`´]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/\s+/g, " ")
    .slice(0, 24);
}
function clubKeyOf(name) {
  return normClubName(name)
    .toLowerCase()
    .replace(/['"]/g, "")
    .replace(/[^a-z0-9а-яё]+/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}
function hashClubPassSha(pass, salt) {
  return createHash("sha256").update(`${salt}:${pass}`).digest("hex");
}
async function hashClubPass(pass) {
  return bcrypt.hash(String(pass), 10);
}
async function checkClubPass(pass, hash, salt) {
  const h = String(hash || "");
  if (h.startsWith("$2")) return bcrypt.compare(String(pass), h);
  return h === hashClubPassSha(pass, salt);
}
async function verifyAndUpgrade(club, pass) {
  const ok = await checkClubPass(pass, club.passHash, club.salt);
  if (!ok) return false;
  if (!String(club.passHash || "").startsWith("$2")) {
    club.passHash = await hashClubPass(pass);
    club.salt = undefined;
  }
  return true;
}
function leaveClub(socket) {
  const key = socketClub.get(socket.id);
  if (!key) return;
  socketClub.delete(socket.id);
  const club = clubs.get(key);
  socket.leave("club:" + key);
  if (!club) return;
  club.members.delete(socket.id);
  dropFromTables(club, socket.id);
  io.to("club:" + key).emit("club:update", publicClub(club));
  saveSnapshot();
}
function seatInClub(club, key, socket, nick, uid) {
  const idKey = String(uid || "").slice(0, 48);
  for (const [id, m] of [...club.members]) {
    if (id === socket.id) continue;
    const sameUid = idKey && m.uid && m.uid === idKey;
    if (!sameUid) continue;
    club.members.delete(id);
    socketClub.delete(id);
    const old = io.sockets.sockets.get(id);
    if (old) {
      old.leave("club:" + key);
      old.emit("club:replaced");
    }
  }
  club.members.set(socket.id, { id: socket.id, name: nick, uid: idKey || socket.id });
  socketClub.set(socket.id, key);
  socket.join("club:" + key);
  boardPlayer(club, nick);
  saveSnapshot();
  return publicClub(club);
}
function tableNeed(mode) {
  return mode === "2x2" ? 4 : mode === "three" ? 3 : 2;
}
function dropFromTables(club, socketId) {
  if (!club?.tables) return;
  club.tables = club.tables.filter((tb) => {
    if (tb.opened) return true;
    tb.sitting = tb.sitting.filter((s) => s.id !== socketId);
    if (tb.sitting.length < tb.need && tb.starting) {
      if (tb.startTimer) clearTimeout(tb.startTimer);
      tb.startTimer = null;
      tb.starting = false;
    }
    if (tb.sitting.length === 0 && tb.startTimer) {
      clearTimeout(tb.startTimer);
      tb.startTimer = null;
    }
    return tb.sitting.length > 0;
  });
}
function launchClubMatch(club, key, tb) {
  if (!tb || tb.opened || tb.sitting.length < tb.need) return;
  tb.opened = true;
  tb.starting = false;
  if (tb.startTimer) {
    clearTimeout(tb.startTimer);
    tb.startTimer = null;
  }
  const mode = tb.mode === "three" ? "3" : tb.mode === "2x2" ? "2x2" : "1x1";
  const id = randomBytes(8).toString("hex");
  const code = uniqueCode();
  const players = new Map();
  tb.sitting.forEach((s, i) => {
    players.set(s.id, {
      id: s.id,
      name: s.name,
      seat: i,
      ready: false,
      socketId: s.id,
    });
  });
  const room = {
    id,
    code,
    hostId: tb.hostId,
    mode,
    maxPlayers: tb.need,
    players,
    createdAt: Date.now(),
    state: null,
    started: false,
    target: tb.target || 51,
    matchTo: tb.matchTo || 1,
    clubKey: key,
    fromClub: true,
  };
  rooms.set(id, room);
  for (const s of tb.sitting) {
    socketRoom.set(s.id, id);
    const sock = io.sockets.sockets.get(s.id);
    if (sock) sock.join(id);
  }
  const out = publicRoom(room);
  io.to(id).emit("club:lobby", { room: out, no: tb.no });
  io.to(id).emit("room:update", out);
  io.to("club:" + key).emit("club:update", publicClub(club));
}

function beginClubCountdown(club, key, tb) {
  if (!tb || tb.opened || tb.starting || tb.sitting.length < tb.need) return;
  tb.starting = true;
  const payload = {
    no: tb.no,
    sec: 5,
    mode: tb.mode,
    target: tb.target,
    matchTo: tb.matchTo,
    sitting: tb.sitting.map((s) => s.name),
  };
  for (const s of tb.sitting) {
    io.to(s.id).emit("club:table:starting", payload);
  }
  tb.startTimer = setTimeout(() => {
    try {
      launchClubMatch(club, key, tb);
    } catch (e) {
      console.error(e);
    }
  }, 5200);
}

function waitKey(mode, target, matchTo) {
  return `${mode}:${Number(target) || 21}:${Number(matchTo) || 1}`;
}
function setWaiting(room) {
  const key = waitKey(room.mode, room.target, room.matchTo);
  if (!room.started && uniquePeople(room) < room.maxPlayers) waiting.set(key, room.id);
  else waiting.delete(key);
}
function clearWaiting(room) {
  const key = waitKey(room.mode, room.target, room.matchTo);
  if (waiting.get(key) === room.id) waiting.delete(key);
}
function normNick(n) {
  return String(n || "").trim().toLowerCase();
}
function personKey(p) {
  if (p?.uid) return "u:" + String(p.uid).slice(0, 48);
  return "n:" + normNick(p?.name);
}
function samePerson(p, who) {
  if (!p || !who) return false;
  if (who.socketId && p.socketId === who.socketId) return true;
  if (who.id && (p.id === who.id || p.socketId === who.id)) return true;
  const uid = String(who.uid || "").slice(0, 48);
  if (uid && p.uid && p.uid === uid) return true;
  const nick = normNick(who.name);
  if (nick && normNick(p.name) === nick) {
    if (uid && p.uid && p.uid !== uid) return false;
    return true;
  }
  return false;
}
function uniquePeople(room) {
  const keys = new Set();
  for (const p of room.players.values()) keys.add(personKey(p));
  return keys.size;
}
function findOwnSeat(who, pred) {
  for (const room of rooms.values()) {
    if (pred && !pred(room)) continue;
    for (const p of room.players.values()) {
      if (samePerson(p, who)) return { room, player: p };
    }
  }
  return null;
}
function claimSeat(socket, room, player, extras = {}) {
  const who = {
    uid: extras.uid || player.uid,
    name: extras.name || player.name,
    id: socket.id,
    socketId: socket.id,
  };
  for (const [id, p] of [...room.players.entries()]) {
    if (p === player) continue;
    if (!samePerson(p, who)) continue;
    if (p.awayTimer) {
      clearTimeout(p.awayTimer);
      p.awayTimer = null;
    }
    room.players.delete(id);
    socketRoom.delete(p.socketId || id);
  }
  const oldSock = player.socketId;
  socketRoom.set(socket.id, room.id);
  socket.join(room.id);
  if (oldSock && oldSock !== socket.id) {
    socketRoom.delete(oldSock);
    const stale = io.sockets.sockets.get(oldSock);
    if (stale) {
      try { stale.leave(room.id); } catch { /* ignore */ }
    }
  }
  if (extras.name) player.name = extras.name;
  if (extras.uid) player.uid = extras.uid;
  if (extras.ip) player.ip = extras.ip;
  markBack(room, player, socket.id);
  player.away = false;
  player.gaveUpWait = false;
  return publicRoom(room);
}
function isLiveGame(room) {
  if (!room?.started || !room.core) return false;
  const ph = room.core.phase;
  return ph === "playing" || ph === "roundOver";
}
function normMatchTo(n) {
  const v = Number(n);
  return [1, 3, 5, 7].includes(v) ? v : 1;
}

function code6() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const buf = randomBytes(6);
  let s = "";
  for (let i = 0; i < 6; i++) s += alphabet[buf[i] % alphabet.length];
  return s;
}

function uniqueCode() {
  for (let i = 0; i < 20; i++) {
    const c = code6();
    if (![...rooms.values()].some((r) => r.code === c)) return c;
  }
  return code6() + code6().slice(0, 2);
}

function publicRoom(room) {
  return {
    id: room.id,
    code: room.code,
    mode: room.mode,
    maxPlayers: room.maxPlayers,
    createdAt: room.createdAt,
    target: room.target || 21,
    matchTo: room.matchTo || 1,
    started: !!room.started,
    players: [...room.players.values()].map((p) => ({
      id: p.id,
      name: p.name,
      seat: p.seat,
      ready: p.ready,
      away: !!p.away,
    })),
    state: room.state,
  };
}

/* Клиент шлёт свои коды режимов, в правилах имена другие.
   Держим сведение в одном месте, чтобы не разъехалось. */
const MODE_MAP = { "1x1": "heads", "2x2": "2x2", "3": "three" };
const ruleMode = (mode) => MODE_MAP[mode] || "heads";

function maxForMode(mode) {
  const t = TABLES[ruleMode(mode)];
  return t ? t.seats : 2;
}

// --- HTTP ---
app.get("/status", (_req, res) => {
  res.json({
    ok: true,
    service: "prodominoes",
    step: 2,
    judge: true,
    rooms: rooms.size,
    clubs: clubs.size,
    time: new Date().toISOString(),
  });
});

app.get("/health", (_req, res) => {
  res.json({ ok: true, step: 2, judge: true, rooms: rooms.size, clubs: clubs.size });
});

app.get("/rooms", (_req, res) => {
  res.json({
    rooms: [...rooms.values()].map((r) => ({
      code: r.code,
      mode: r.mode,
      players: r.players.size,
      maxPlayers: r.maxPlayers,
    })),
  });
});

/* Письма с кодом. Код живёт только здесь, клиент его не видит.
   Без RESEND_API_KEY эндпоинт отвечает nomail — клиент тогда
   создаёт аккаунт сразу, чтобы друзья не застряли. */
const RESEND_KEY = String(process.env.RESEND_API_KEY || "").trim();
const MAIL_FROM = String(process.env.MAIL_FROM || "ProDominoes <onboarding@resend.dev>").trim();
const mailIpTries = new Map(); // ip -> { n, until }
const mailAddrTries = new Map(); // email -> { n, until }
const pendingMail = new Map(); // email -> { hash, exp, tries }
const resetTok = new Map(); // token -> { email, exp }

function httpIp(req) {
  const fwd = req.headers["x-forwarded-for"];
  if (fwd) {
    const first = String(Array.isArray(fwd) ? fwd[0] : fwd).split(",")[0].trim();
    if (first) return first;
  }
  return req.socket?.remoteAddress || "unknown";
}
function mailLimited(map, key, max, windowMs) {
  const now = Date.now();
  const rec = map.get(key);
  if (!rec || now > rec.until) return false;
  return rec.n >= max;
}
function mailNote(map, key, windowMs) {
  const now = Date.now();
  const rec = map.get(key);
  if (!rec || now > rec.until) map.set(key, { n: 1, until: now + windowMs });
  else rec.n += 1;
}
function hashMailCode(code) {
  return createHash("sha256").update("pd-mail:" + String(code)).digest("hex");
}
function mailOk(s) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(s || ""));
}
async function sendResend(to, code, lang) {
  const ru = lang !== "en";
  const subject = ru ? `Код ProDominoes: ${code}` : `ProDominoes code: ${code}`;
  const html = ru
    ? `<div style="font-family:sans-serif;background:#0E1116;color:#E9E6DF;padding:28px">
        <div style="font-size:13px;letter-spacing:2px;color:#E4BE6A">PRODOMINOES</div>
        <p style="margin:16px 0 8px">Код подтверждения:</p>
        <p style="font-size:32px;letter-spacing:10px;font-weight:800;margin:0">${code}</p>
        <p style="color:#8a8680;font-size:13px;margin-top:16px">Действует 10 минут. Если это не вы — удалите письмо.</p>
      </div>`
    : `<div style="font-family:sans-serif;background:#0E1116;color:#E9E6DF;padding:28px">
        <div style="font-size:13px;letter-spacing:2px;color:#E4BE6A">PRODOMINOES</div>
        <p style="margin:16px 0 8px">Your confirmation code:</p>
        <p style="font-size:32px;letter-spacing:10px;font-weight:800;margin:0">${code}</p>
        <p style="color:#8a8680;font-size:13px;margin-top:16px">Valid for 10 minutes. If this wasn't you, ignore the email.</p>
      </div>`;
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${RESEND_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ from: MAIL_FROM, to: [to], subject, html }),
  });
  if (!r.ok) {
    const body = await r.text().catch(() => "");
    console.error("resend fail", r.status);
    if (body) console.error("resend body", body.slice(0, 240));
    return false;
  }
  return true;
}

app.get("/auth/status", (_req, res) => {
  res.json({ ok: true, mail: Boolean(RESEND_KEY) });
});

app.post("/auth/send", async (req, res) => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  const lang = req.body?.lang === "en" ? "en" : "ru";
  if (!mailOk(email)) return res.status(400).json({ ok: false, error: "mail" });
  if (!RESEND_KEY) return res.status(503).json({ ok: false, error: "nomail" });
  const ip = httpIp(req);
  if (mailLimited(mailIpTries, ip, 8, 15 * 60_000) || mailLimited(mailAddrTries, email, 4, 15 * 60_000)) {
    return res.status(429).json({ ok: false, error: "limit" });
  }
  mailNote(mailIpTries, ip, 15 * 60_000);
  mailNote(mailAddrTries, email, 15 * 60_000);
  const code = String(100000 + ((Math.random() * 900000) | 0));
  pendingMail.set(email, { hash: hashMailCode(code), exp: Date.now() + 10 * 60_000, tries: 0 });
  const sent = await sendResend(email, code, lang);
  if (!sent) {
    pendingMail.delete(email);
    return res.status(502).json({ ok: false, error: "send" });
  }
  res.json({ ok: true });
});

app.post("/auth/confirm", (req, res) => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  const code = String(req.body?.code || "").replace(/\D/g, "");
  if (!mailOk(email) || code.length !== 6) return res.status(400).json({ ok: false, error: "bad" });
  const rec = pendingMail.get(email);
  if (!rec || Date.now() > rec.exp) {
    pendingMail.delete(email);
    return res.status(400).json({ ok: false, error: "expired" });
  }
  rec.tries += 1;
  if (rec.tries > 5) {
    pendingMail.delete(email);
    return res.status(429).json({ ok: false, error: "limit" });
  }
  if (rec.hash !== hashMailCode(code)) return res.status(400).json({ ok: false, error: "bad" });
  pendingMail.delete(email);
  const token = randomBytes(16).toString("hex");
  resetTok.set(token, { email, exp: Date.now() + 15 * 60_000 });
  res.json({ ok: true, token });
});

setInterval(() => {
  const now = Date.now();
  for (const [k, rec] of mailIpTries) if (now > rec.until) mailIpTries.delete(k);
  for (const [k, rec] of mailAddrTries) if (now > rec.until) mailAddrTries.delete(k);
  for (const [k, rec] of pendingMail) if (now > rec.exp) pendingMail.delete(k);
  for (const [k, rec] of resetTok) if (now > rec.exp) resetTok.delete(k);
}, 60_000).unref();

/* ============================================================
   СУДЬЯ

   Состояние партии живёт здесь, а не у игроков. Клиент присылает
   только намерение — «хочу положить такую-то кость такой-то стороной».
   Сервер прогоняет его через reduce (тот же файл правил, что у экрана)
   и рассылает результат.

   Клиент состояние не присылает: иначе любой мог бы объявить себя
   победителем. Место игрока сервер тоже определяет сам, из сообщения
   не берёт.
   ============================================================ */

// раздача по числу: партию можно воспроизвести для разбора жалоб
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function groupsOf(room) {
  const mode = ruleMode(room.mode);
  return mode === "2x2" ? 2 : TABLES[mode].seats;
}

function ensureMatch(room) {
  const g = groupsOf(room);
  if (!Array.isArray(room.matches) || room.matches.length !== g) room.matches = Array(g).fill(0);
  if (!Array.isArray(room.dries) || room.dries.length !== g) room.dries = Array(g).fill(0);
  if (!Number.isFinite(room.gamesPlayed)) room.gamesPlayed = 0;
}

function applyCore(room, next) {
  const prev = room.core?.phase;
  room.core = next;
  room.seq = (room.seq || 0) + 1;
  if (next.phase === "gameOver" && prev !== "gameOver") {
    ensureMatch(room);
    const r = next.result || {};
    const champ = r.champ;
    if (Number.isInteger(champ)) {
      room.matches[champ] = (room.matches[champ] || 0) + (r.points || 1);
      if (r.dry) room.dries[champ] = (room.dries[champ] || 0) + 1;
      room.gamesPlayed += 1;
    }
  }
}

function startRound(room, gameNo = 1) {
  const mode = ruleMode(room.mode);
  const T = TABLES[mode];
  const seed = (Math.random() * 2 ** 31) >>> 0;
  const rng = mulberry32(seed);
  const { h, rest } = dealFor(mode, rng);
  const { dbl, opener } = pickOpening(h, gameNo);
  const groups = mode === "2x2" ? 2 : T.seats;
  room.seed = seed;
  room.gameNo = gameNo;
  room.core = {
    ...emptyCore(),
    mode,
    seats: T.seats,
    target: room.target || 51,
    hands: h,
    bazaar: rest,
    locked: T.locked,
    chain: [],
    turn: opener,
    starter: opener,
    passes: 0,
    firstRound: true,
    opening: dbl,
    scores: Array(groups).fill(0),
    bank: Array(groups).fill(0),
    fishPot: 0,
    fishWaitOpen: false,
    phase: "playing",
    result: null,
  };
  room.seq = (room.seq || 0) + 1;
  room.seenMoves = new Set();
  if (gameNo === 1) {
    const g = groupsOf(room);
    room.matches = Array(g).fill(0);
    room.dries = Array(g).fill(0);
    room.gamesPlayed = 0;
  }
}

/* Срез состояния под конкретного игрока.

   Никогда не отправляем hands целиком: там руки всех, и любой
   открыл бы консоль и увидел чужие кости. Своя рука — целиком,
   у остальных только количество, базар — числом. */
function viewFor(room, seat) {
  const c = room.core;
  if (!c) return null;
  return {
    mode: c.mode,
    seats: c.seats,
    target: c.target,
    chain: c.chain,
    turn: c.turn,
    starter: c.starter,
    passes: c.passes,
    firstRound: c.firstRound,
    opening: c.opening,
    scores: c.scores,
    bank: c.bank,
    fishPot: c.fishPot,
    fishWaitOpen: c.fishWaitOpen,
    lastPlay: c.lastPlay || null,
    lastDraw: c.lastDraw || null,
    phase: c.phase,
    result: c.result
      ? { ...c.result, hands: c.phase === "playing" ? undefined : c.result.hands }
      : null,
    locked: c.locked,
    myHand: c.hands[seat] || [],
    handCounts: c.hands.map((x) => x.length),
    bazaarLeft: c.bazaar.length,
    mySeat: seat,
    seq: room.seq,
    deadline: room.deadline || null,
    now: Date.now(),
    away: [...room.players.values()].filter((p) => p.away).map((p) => p.seat),
    matches: room.matches || null,
    dries: room.dries || null,
    gamesPlayed: room.gamesPlayed || 0,
    matchTo: room.matchTo || 1,
  };
}

// каждому — своё, персонально
function pushState(room) {
  for (const p of room.players.values()) {
    io.to(p.socketId).emit("game:state", viewFor(room, p.seat));
  }
}

function seatOf(room, socketId) {
  const p = room.players.get(socketId);
  return p ? p.seat : -1;
}

/* ============================================================
   ТАЙМЕР ХОДА И ОБРЫВЫ СВЯЗИ

   Время считает сервер. Если бы считал телефон, любой сдвинул бы
   часы и думал сколько угодно.

   При обрыве место игрока НЕ освобождается до конца партии: иначе
   вернувшийся обнаружил бы на своём стуле чужого. Минуту ждём с
   остановленными часами, потом за него доигрывает бот.
   ============================================================ */

const TURN_MS = 10_000; // столько же, сколько на экране
const GRACE_MS = 60_000; // сколько ждём вернувшегося

function clearTurnTimer(room) {
  if (room.turnTimer) {
    clearTimeout(room.turnTimer);
    room.turnTimer = null;
  }
}

// чей сейчас ход и на связи ли он
function seatPlayer(room, seat) {
  for (const p of room.players.values()) if (p.seat === seat) return p;
  return null;
}

function armTurn(room) {
  clearTurnTimer(room);
  if (!room.core || room.core.phase !== "playing") return;
  const p = seatPlayer(room, room.core.turn);
  if (p && p.away) {
    room.deadline = null;
    if (p.gaveUpWait) {
      room.turnTimer = setTimeout(() => autoMove(room, "away"), 700);
    }
    return;
  }
  room.deadline = Date.now() + TURN_MS;
  room.turnTimer = setTimeout(() => autoMove(room, "timeout"), TURN_MS + 200);
}

/* Ход за игрока: по истечении времени или пока он не вернулся.
   Пользуемся тем же aiPick, что и офлайновые боты. */
function autoMove(room, why) {
  if (!room.core || room.core.phase !== "playing") return;
  const seat = room.core.turn;
  const c = room.core;
  const forced = c.firstRound && c.chain.length === 0 ? c.opening : null;
  const m = aiPick(c.hands[seat], c.chain, forced, Math.random, 0.38);
  let next;
  if (m) next = reduce(c, { type: "play", seat, tile: m.tile, side: m.side });
  else if (c.bazaar.length > c.locked) next = reduce(c, { type: "draw", seat });
  else next = reduce(c, { type: "pass", seat });
  if (!next || next.error) return;
  applyCore(room, next);
  io.to(room.id).emit("game:auto", { seat, why });
  armTurn(room);
  pushState(room);
  saveSnapshot();
}

// пока игрок не вернулся, за него ходят — иначе стол встанет навсегда
function resumeAwayTurns(room) {
  if (!room.core || room.core.phase !== "playing") return;
  const p = seatPlayer(room, room.core.turn);
  if (p && p.away && p.gaveUpWait) {
    autoMove(room, "away");
  }
}

function markAway(room, player) {
  player.away = true;
  player.awayAt = Date.now();
  player.gaveUpWait = false;
  clearTurnTimer(room);
  room.deadline = null;
  io.to(room.id).emit("room:update", publicRoom(room));
  pushState(room); // соперники должны увидеть, что человек отошёл
  // минута на возвращение; часы всё это время стоят
  player.awayTimer = setTimeout(() => {
    player.gaveUpWait = true;
    io.to(room.id).emit("player:replaced", { seat: player.seat });
    pushState(room);
    resumeAwayTurns(room);
    armTurn(room);
  }, GRACE_MS);
}

function markBack(room, player, socketId) {
  if (player.awayTimer) {
    clearTimeout(player.awayTimer);
    player.awayTimer = null;
  }
  player.away = false;
  player.gaveUpWait = false;
  const oldId = player.socketId;
  player.socketId = socketId;
  player.id = socketId;
  if (room.hostId === oldId) room.hostId = socketId;
  if (oldId !== socketId) {
    room.players.delete(oldId);
    room.players.set(socketId, player);
  }
  io.to(room.id).emit("room:update", publicRoom(room));
  if (room.core && room.core.phase === "playing") {
    armTurn(room);
    pushState(room);
  }
}

const HOLD_MS = 5 * 60_000;

function markHold(room, player) {
  player.away = true;
  player.awayAt = Date.now();
  player.gaveUpWait = false;
  if (player.awayTimer) clearTimeout(player.awayTimer);
  io.to(room.id).emit("room:update", publicRoom(room));
  player.awayTimer = setTimeout(() => {
    if (!player.away || room.started) return;
    room.players.delete(player.id);
    socketRoom.delete(player.socketId);
    if (room.players.size === 0) {
      clearWaiting(room);
      rooms.delete(room.id);
      return;
    }
    setWaiting(room);
    io.to(room.id).emit("room:update", publicRoom(room));
  }, HOLD_MS);
}

// --- Socket ---
io.on("connection", (socket) => {
  socket.emit("hello", { ok: true, step: 2, judge: true, id: socket.id });

  socket.on("club:create", async (payload = {}, ack) => {
    try {
      const name = normClubName(payload.name);
      const pass = String(payload.pass || "");
      const nick = String(payload.nick || "Игрок").slice(0, 24);
      const uid = String(payload.uid || "").slice(0, 48);
      const gated = needClubAccount(payload);
      if (gated) {
        if (typeof ack === "function") ack({ ok: false, error: gated });
        return;
      }
      if (name.length < 2 || pass.length < 3) {
        if (typeof ack === "function") ack({ ok: false, error: "bad_input" });
        return;
      }
      const key = clubKeyOf(name);
      if (clubs.has(key)) {
        const club = clubs.get(key);
        if (!(await verifyAndUpgrade(club, pass))) {
          if (typeof ack === "function") ack({ ok: false, error: "club_exists" });
          return;
        }
        if (socketClub.get(socket.id) !== key) leaveClub(socket);
        const out = seatInClub(club, key, socket, nick, uid);
        if (typeof ack === "function") ack({ ok: true, club: out, role: club.hostId === socket.id ? "host" : "member" });
        io.to("club:" + key).emit("club:update", out);
        return;
      }
      leaveClub(socket);
      const club = {
        name,
        passHash: await hashClubPass(pass),
        hostId: socket.id,
        members: new Map(),
        tables: [],
        createdAt: Date.now(),
        board: payload.board && payload.board.stats ? payload.board : emptyBoard(),
        hostEmail: String(payload.email || "").trim().toLowerCase() || undefined,
      };
      clubs.set(key, club);
      const out = seatInClub(club, key, socket, nick, uid);
      if (typeof ack === "function") ack({ ok: true, club: out, role: "host" });
      socket.emit("club:update", out);
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("club:join", async (payload = {}, ack) => {
    try {
      const ip = clientIp(socket);
      if (tooManyTries(ip)) {
        if (typeof ack === "function") ack({ ok: false, error: "too_many_tries" });
        return;
      }
      const name = normClubName(payload.name);
      const pass = String(payload.pass || "");
      const nick = String(payload.nick || "Игрок").slice(0, 24);
      const uid = String(payload.uid || "").slice(0, 48);
      const gated = needClubAccount(payload);
      if (gated) {
        if (typeof ack === "function") ack({ ok: false, error: gated });
        return;
      }
      const key = clubKeyOf(name);
      const club = clubs.get(key);
      if (!club) {
        if (typeof ack === "function") ack({ ok: false, error: "club_not_found" });
        return;
      }
      if (!(await verifyAndUpgrade(club, pass))) {
        noteFail(ip);
        if (typeof ack === "function") ack({ ok: false, error: "bad_password" });
        return;
      }
      joinTries.delete(ip);
      if (socketClub.get(socket.id) !== key) leaveClub(socket);
      const out = seatInClub(club, key, socket, nick, uid);
      if (typeof ack === "function") ack({ ok: true, club: out, role: club.hostId === socket.id ? "host" : "member" });
      io.to("club:" + key).emit("club:update", out);
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("club:reset", async (payload = {}, ack) => {
    try {
      const token = String(payload.token || "");
      const rec = resetTok.get(token);
      if (!rec || Date.now() > rec.exp) {
        if (typeof ack === "function") ack({ ok: false, error: "need_reg" });
        return;
      }
      const name = normClubName(payload.name);
      const pass = String(payload.pass || "");
      const nick = String(payload.nick || "Игрок").slice(0, 24);
      const uid = String(payload.uid || "").slice(0, 48);
      if (name.length < 2 || pass.length < 3) {
        if (typeof ack === "function") ack({ ok: false, error: "bad_input" });
        return;
      }
      const key = clubKeyOf(name);
      let club = clubs.get(key);
      if (club && club.hostEmail && club.hostEmail !== rec.email) {
        if (typeof ack === "function") ack({ ok: false, error: "bad_password" });
        return;
      }
      if (!club) {
        club = {
          name,
          passHash: await hashClubPass(pass),
          hostId: socket.id,
          members: new Map(),
          tables: [],
          createdAt: Date.now(),
          board: emptyBoard(),
          hostEmail: rec.email,
        };
        clubs.set(key, club);
      } else {
        club.passHash = await hashClubPass(pass);
        club.hostEmail = rec.email;
      }
      resetTok.delete(token);
      if (socketClub.get(socket.id) !== key) leaveClub(socket);
      const out = seatInClub(club, key, socket, nick, uid);
      if (typeof ack === "function") ack({ ok: true, club: out });
      io.to("club:" + key).emit("club:update", out);
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("club:leave", (_payload, ack) => {
    leaveClub(socket);
    if (typeof ack === "function") ack({ ok: true });
  });

  socket.on("club:result", (payload = {}, ack) => {
    const key = socketClub.get(socket.id);
    const club = key && clubs.get(key);
    if (!club) {
      if (typeof ack === "function") ack({ ok: false, error: "no_club" });
      return;
    }
    applyClubResult(club, payload || {});
    const out = publicClub(club);
    io.to("club:" + key).emit("club:update", out);
    saveSnapshot();
    if (typeof ack === "function") ack({ ok: true, club: out });
  });

  socket.on("club:table:create", (payload = {}, ack) => {
    try {
      const key = socketClub.get(socket.id);
      const club = key && clubs.get(key);
      if (!club) {
        if (typeof ack === "function") ack({ ok: false, error: "not_in_club" });
        return;
      }
      if ((club.tables || []).some((tb) => !tb.opened && tb.hostId === socket.id)) {
        if (typeof ack === "function") ack({ ok: false, error: "table_exists" });
        return;
      }
      const mode = ["heads", "2x2", "three"].includes(payload.mode) ? payload.mode : "heads";
      const need = tableNeed(mode);
      const me = club.members.get(socket.id);
      club.tables = club.tables || [];
      const no = (club.tableSeq = (club.tableSeq || 0) + 1);
      const tb = {
        no,
        mode,
        need,
        target: Number(payload.target) > 0 ? Number(payload.target) : 51,
        matchTo: Number(payload.matchTo) > 0 ? Number(payload.matchTo) : 1,
        hostId: socket.id,
        sitting: [{ id: socket.id, name: me?.name || "Игрок" }],
        opened: false,
      };
      club.tables.push(tb);
      const out = publicClub(club);
      if (typeof ack === "function") ack({ ok: true, club: out, no });
      io.to("club:" + key).emit("club:update", out);
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("club:table:join", (payload = {}, ack) => {
    try {
      const key = socketClub.get(socket.id);
      const club = key && clubs.get(key);
      if (!club) {
        if (typeof ack === "function") ack({ ok: false, error: "not_in_club" });
        return;
      }
      const no = Number(payload.no);
      const tb = (club.tables || []).find((t) => t.no === no && !t.opened);
      if (!tb) {
        if (typeof ack === "function") ack({ ok: false, error: "table_gone" });
        return;
      }
      if (tb.sitting.some((s) => s.id === socket.id)) {
        if (typeof ack === "function") ack({ ok: true, club: publicClub(club) });
        return;
      }
      if (tb.sitting.length >= tb.need) {
        if (typeof ack === "function") ack({ ok: false, error: "table_full" });
        return;
      }
      const me = club.members.get(socket.id);
      tb.sitting.push({ id: socket.id, name: me?.name || "Игрок" });
      const out = publicClub(club);
      if (typeof ack === "function") ack({ ok: true, club: out });
      io.to("club:" + key).emit("club:update", out);
      if (tb.sitting.length >= tb.need) beginClubCountdown(club, key, tb);
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("club:invite", (payload = {}, ack) => {
    try {
      const key = socketClub.get(socket.id);
      const club = key && clubs.get(key);
      if (!club) {
        if (typeof ack === "function") ack({ ok: false, error: "not_in_club" });
        return;
      }
      const no = Number(payload.no);
      const tb = (club.tables || []).find((t) => t.no === no && !t.opened);
      if (!tb || tb.hostId !== socket.id) {
        if (typeof ack === "function") ack({ ok: false, error: "no_table" });
        return;
      }
      const want = String(payload.name || "").trim().toLowerCase();
      const target = [...club.members.values()].find(
        (m) => m.id !== socket.id && String(m.name || "").trim().toLowerCase() === want
      );
      if (!target) {
        if (typeof ack === "function") ack({ ok: false, error: "not_in_club" });
        return;
      }
      const from = club.members.get(socket.id);
      io.to(target.id).emit("club:invited", {
        no: tb.no,
        from: from?.name || "",
        mode: tb.mode,
        table: publicTable(tb),
      });
      if (typeof ack === "function") ack({ ok: true });
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("club:invite:reply", (payload = {}, ack) => {
    try {
      const key = socketClub.get(socket.id);
      const club = key && clubs.get(key);
      if (!club) {
        if (typeof ack === "function") ack({ ok: false, error: "not_in_club" });
        return;
      }
      const no = Number(payload.no);
      const tb = (club.tables || []).find((t) => t.no === no && !t.opened);
      const me = club.members.get(socket.id);
      if (tb) {
        io.to(tb.hostId).emit("club:invite:result", {
          no,
          ok: !!payload.ok,
          name: me?.name || "",
        });
      }
      if (payload.ok && tb && !tb.opened) {
        if (!tb.sitting.some((s) => s.id === socket.id) && tb.sitting.length < tb.need) {
          tb.sitting.push({ id: socket.id, name: me?.name || "Игрок" });
          const out = publicClub(club);
          io.to("club:" + key).emit("club:update", out);
          if (tb.sitting.length >= tb.need) beginClubCountdown(club, key, tb);
          if (typeof ack === "function") ack({ ok: true, club: out });
          return;
        }
      }
      if (typeof ack === "function") ack({ ok: true, club: publicClub(club) });
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("club:table:cancel", (payload = {}, ack) => {
    try {
      const key = socketClub.get(socket.id);
      const club = key && clubs.get(key);
      if (!club) {
        if (typeof ack === "function") ack({ ok: false, error: "not_in_club" });
        return;
      }
      const no = Number(payload.no);
      const tb = (club.tables || []).find((t) => t.no === no);
      if (!tb || tb.hostId !== socket.id) {
        if (typeof ack === "function") ack({ ok: false, error: "no_table" });
        return;
      }
      if (tb.startTimer) clearTimeout(tb.startTimer);
      club.tables = club.tables.filter((t) => t.no !== no);
      const out = publicClub(club);
      io.to("club:" + key).emit("club:update", out);
      if (typeof ack === "function") ack({ ok: true, club: out });
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("club:table:leave", (payload = {}, ack) => {
    try {
      const key = socketClub.get(socket.id);
      const club = key && clubs.get(key);
      if (!club) {
        if (typeof ack === "function") ack({ ok: false });
        return;
      }
      dropFromTables(club, socket.id);
      const out = publicClub(club);
      io.to("club:" + key).emit("club:update", out);
      if (typeof ack === "function") ack({ ok: true, club: out });
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("room:create", (payload = {}, ack) => {
    try {
      const name = String(payload.name || "Host").slice(0, 24);
      const uid = String(payload.uid || "").slice(0, 48);
      const ip = clientIp(socket);
      const mode = ["1x1", "2x2", "3"].includes(payload.mode) ? payload.mode : "1x1";
      const maxPlayers = maxForMode(mode);
      const id = randomBytes(8).toString("hex");
      const code = uniqueCode();
      const player = {
        id: socket.id,
        name,
        uid,
        ip,
        seat: 0,
        ready: false,
        socketId: socket.id,
      };
      /** @type {Room} */
      const room = {
        id,
        code,
        hostId: socket.id,
        mode,
        maxPlayers,
        players: new Map([[socket.id, player]]),
        createdAt: Date.now(),
        state: null,
        started: false,
        target: Number(payload.target) > 0 ? Number(payload.target) : 21,
        matchTo: normMatchTo(payload.matchTo),
        openChat: true,
      };
      rooms.set(id, room);
      socketRoom.set(socket.id, id);
      socket.join(id);
      setWaiting(room);
      const out = publicRoom(room);
      if (typeof ack === "function") ack({ ok: true, room: out });
      socket.emit("room:update", out);
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("room:join", (payload = {}, ack) => {
    try {
      const code = String(payload.code || "")
        .trim()
        .toUpperCase();
      const name = String(payload.name || "Player").slice(0, 24);
      const uid = String(payload.uid || "").slice(0, 48);
      const ip = clientIp(socket);
      const who = { uid, name, ip, id: socket.id, socketId: socket.id };
      const room = [...rooms.values()].find((r) => r.code === code);
      if (!room) {
        if (typeof ack === "function") ack({ ok: false, error: "room_not_found" });
        return;
      }
      const mine = findOwnSeat(who, (r) => r.id === room.id);
      if (mine) {
        const out = claimSeat(socket, mine.room, mine.player, { name, uid, ip });
        if (typeof ack === "function") ack({ ok: true, room: out });
        io.to(room.id).emit("room:update", out);
        if (room.core) socket.emit("game:state", viewFor(room, mine.player.seat));
        return;
      }
      if (uniquePeople(room) >= room.maxPlayers) {
        if (typeof ack === "function") ack({ ok: false, error: "room_full" });
        return;
      }
      // уже в комнате — переподключение
      if (room.players.has(socket.id)) {
        socket.join(room.id);
        socketRoom.set(socket.id, room.id);
        const out = publicRoom(room);
        if (typeof ack === "function") ack({ ok: true, room: out });
        return;
      }
      const usedSeats = new Set([...room.players.values()].map((p) => p.seat));
      let seat = 0;
      while (usedSeats.has(seat) && seat < room.maxPlayers) seat++;
      const player = {
        id: socket.id,
        name,
        uid,
        ip,
        seat,
        ready: false,
        socketId: socket.id,
      };
      room.players.set(socket.id, player);
      socketRoom.set(socket.id, room.id);
      socket.join(room.id);
      setWaiting(room);
      const out = publicRoom(room);
      if (typeof ack === "function") ack({ ok: true, room: out });
      io.to(room.id).emit("room:update", out);
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("table:chat", (payload = {}) => {
    const roomId = socketRoom.get(socket.id);
    const room = roomId && rooms.get(roomId);
    if (!room || !room.openChat) return;
    const text = String(payload.text || "").trim().slice(0, 140);
    if (!text) return;
    const p = room.players.get(socket.id);
    socket.to(room.id).emit("table:chat", {
      from: socket.id,
      name: p?.name || "",
      seat: p?.seat,
      text,
    });
  });

  socket.on("table:voice", (payload = {}) => {
    const roomId = socketRoom.get(socket.id);
    const room = roomId && rooms.get(roomId);
    if (!room || !room.openChat) return;
    const url = String(payload.url || "");
    const dur = Math.max(1, Math.min(8, Number(payload.dur) || 1));
    if (!/^data:audio\//.test(url) || url.length > 450000) return;
    const p = room.players.get(socket.id);
    socket.to(room.id).emit("table:voice", {
      from: socket.id,
      name: p?.name || "",
      seat: p?.seat,
      url,
      dur,
    });
  });

  socket.on("room:find", (payload = {}, ack) => {
    try {
      const name = String(payload.name || "Player").slice(0, 24);
      const uid = String(payload.uid || "").slice(0, 48);
      const ip = clientIp(socket);
      const mode = ["1x1", "2x2", "3"].includes(payload.mode) ? payload.mode : "1x1";
      const target = Number(payload.target) > 0 ? Number(payload.target) : 21;
      const matchTo = normMatchTo(payload.matchTo);
      const who = { uid, name, ip, id: socket.id, socketId: socket.id };

      const ownQueue = findOwnSeat(who, (r) => !r.started && r.mode === mode && Number(r.target || 21) === target && Number(r.matchTo || 1) === matchTo);
      if (ownQueue) {
        const out = claimSeat(socket, ownQueue.room, ownQueue.player, { name, uid, ip });
        const role = ownQueue.player.seat === 0 ? "host" : "guest";
        if (typeof ack === "function") ack({ ok: true, room: out, role });
        io.to(ownQueue.room.id).emit("room:update", out);
        return;
      }
      const ownLive = findOwnSeat(who, isLiveGame);
      if (ownLive) {
        const out = claimSeat(socket, ownLive.room, ownLive.player, { name, uid, ip });
        const role = ownLive.player.seat === 0 ? "host" : "guest";
        if (typeof ack === "function") ack({ ok: true, room: out, role });
        io.to(ownLive.room.id).emit("room:update", out);
        if (ownLive.room.core) {
          const view = viewFor(ownLive.room, ownLive.player.seat);
          if (view) socket.emit("game:state", view);
        }
        return;
      }

      const key = waitKey(mode, target, matchTo);
      const existingId = waiting.get(key);
      const existing = existingId && rooms.get(existingId);
      if (existing && !existing.started && uniquePeople(existing) < existing.maxPlayers && !existing.players.has(socket.id)) {
        const clone = [...existing.players.values()].some((p) => samePerson(p, who));
        if (clone) {
          const mine = [...existing.players.values()].find((p) => samePerson(p, who));
          const out = claimSeat(socket, existing, mine, { name, uid, ip });
          if (typeof ack === "function") ack({ ok: true, room: out, role: mine.seat === 0 ? "host" : "guest" });
          io.to(existing.id).emit("room:update", out);
          return;
        }
        const usedSeats = new Set([...existing.players.values()].map((p) => p.seat));
        let seat = 0;
        while (usedSeats.has(seat) && seat < existing.maxPlayers) seat++;
        const player = { id: socket.id, name, uid, ip, seat, ready: false, socketId: socket.id };
        existing.players.set(socket.id, player);
        socketRoom.set(socket.id, existing.id);
        socket.join(existing.id);
        setWaiting(existing);
        const out = publicRoom(existing);
        if (typeof ack === "function") ack({ ok: true, room: out, role: "guest" });
        io.to(existing.id).emit("room:update", out);
        return;
      }
      const maxPlayers = maxForMode(mode);
      const id = randomBytes(8).toString("hex");
      const code = uniqueCode();
      const player = { id: socket.id, name, uid, ip, seat: 0, ready: false, socketId: socket.id };
      const room = {
        id,
        code,
        hostId: socket.id,
        mode,
        maxPlayers,
        players: new Map([[socket.id, player]]),
        createdAt: Date.now(),
        state: null,
        started: false,
        target,
        matchTo,
        openChat: false,
      };
      rooms.set(id, room);
      socketRoom.set(socket.id, id);
      socket.join(id);
      setWaiting(room);
      const out = publicRoom(room);
      if (typeof ack === "function") ack({ ok: true, room: out, role: "host" });
      socket.emit("room:update", out);
    } catch (e) {
      if (typeof ack === "function") ack({ ok: false, error: String(e.message || e) });
    }
  });

  socket.on("room:ready", (payload = {}, ack) => {
    const roomId = socketRoom.get(socket.id);
    const room = roomId && rooms.get(roomId);
    if (!room) {
      if (typeof ack === "function") ack({ ok: false, error: "not_in_room" });
      return;
    }
    const p = room.players.get(socket.id);
    if (!p) return;
    p.ready = !!payload.ready;
    const out = publicRoom(room);
    io.to(room.id).emit("room:update", out);
    const distinct = uniquePeople(room) === room.maxPlayers;
    const filled = room.players.size === room.maxPlayers;
    const readyAll = [...room.players.values()].every((x) => x.ready);
    const present = [...room.players.values()].every((x) => !x.away);
    if (distinct && filled && readyAll && present && !room.started) {
      room.started = true;
      clearWaiting(room);
      startRound(room, 1);
      io.to(room.id).emit("room:start", { room: out, at: Date.now() });
      armTurn(room);
      pushState(room);
    }
    if (typeof ack === "function") ack({ ok: true, room: out });
  });

  /* Состояние партии клиент больше не присылает — оно живёт на сервере.
     Запрос нужен при переподключении: «дай мне текущую картинку». */
  socket.on("game:state", (_payload = {}, ack) => {
    const roomId = socketRoom.get(socket.id);
    const room = roomId && rooms.get(roomId);
    if (!room) {
      if (typeof ack === "function") ack({ ok: false, error: "not_in_room" });
      return;
    }
    const seat = seatOf(room, socket.id);
    if (seat < 0) {
      if (typeof ack === "function") ack({ ok: false, error: "not_seated" });
      return;
    }
    const view = viewFor(room, seat);
    socket.emit("game:state", view);
    if (typeof ack === "function") ack({ ok: true, state: view });
  });

  socket.on("game:move", (payload = {}, ack) => {
    const fail = (error) => {
      if (typeof ack === "function") ack({ ok: false, error });
    };
    const roomId = socketRoom.get(socket.id);
    const room = roomId && rooms.get(roomId);
    if (!room) return fail("not_in_room");
    if (!room.core) return fail("no_game");

    const seat = seatOf(room, socket.id);
    if (seat < 0) return fail("not_seated");

    /* Повтор одного и того же хода игнорируем: при рывке связи клиент
       шлёт его заново, и без этой проверки кость легла бы дважды. */
    const moveId = payload.moveId ? String(payload.moveId) : null;
    if (moveId && room.seenMoves.has(moveId)) {
      return ack && ack({ ok: true, repeated: true, state: viewFor(room, seat) });
    }

    const type = String(payload.type || "");
    if (!["play", "draw", "pass", "surrender", "nextRound"].includes(type)) {
      return fail("неизвестный ход");
    }

    // очередь проверяет сервер, из сообщения место игрока не берём.
    // следующий круг и сдача — не ходы на столе, место всё равно своё.
    if (type !== "nextRound" && type !== "surrender" && room.core.turn !== seat) {
      return fail("не ваш ход");
    }

    if (type === "nextRound" && room.core.phase === "playing") {
      if (typeof ack === "function") ack({ ok: true, repeated: true, state: viewFor(room, seat) });
      return;
    }

    const next = reduce(room.core, { ...payload, type, seat });
    if (!next || next.error) return fail(next?.error || "ход отклонён");

    applyCore(room, next);
    if (moveId) {
      room.seenMoves.add(moveId);
      if (room.seenMoves.size > 20) {
        room.seenMoves = new Set([...room.seenMoves].slice(-20));
      }
    }
    armTurn(room);
    pushState(room);
    if (room.fromClub && type === "surrender") {
      io.to(room.id).emit("club:match:over", { reason: "surrender" });
      const club = room.clubKey && clubs.get(room.clubKey);
      if (club) io.to("club:" + room.clubKey).emit("club:update", publicClub(club));
    }
    saveSnapshot();
    if (typeof ack === "function") ack({ ok: true, state: viewFor(room, seat) });
  });

  /* Возврат на своё место после обрыва. Клиент помнит код комнаты и
     номер места, присылает их — сервер сажает обратно, даже если за
     него уже ходил бот. Место всё это время держалось за ним. */
  socket.on("room:rejoin", (payload = {}, ack) => {
    const fail = (error) => {
      if (typeof ack === "function") ack({ ok: false, error });
    };
    const code = String(payload.code || "").toUpperCase();
    const seat = Number(payload.seat);
    const name = String(payload.name || "").slice(0, 24);
    const uid = String(payload.uid || "").slice(0, 48);
    const ip = clientIp(socket);
    const who = { uid, name, id: socket.id, socketId: socket.id };
    const room = [...rooms.values()].find((r) => r.code === code);
    if (!room) return fail("комната не найдена");
    const mine = findOwnSeat(who, (r) => r.id === room.id);
    const player = mine?.player || seatPlayer(room, seat);
    if (!player) return fail("место не найдено");
    if (mine) {
      const out = claimSeat(socket, room, mine.player, { name: name || mine.player.name, uid, ip });
      const view = room.core ? viewFor(room, mine.player.seat) : null;
      if (view) socket.emit("game:state", view);
      if (typeof ack === "function") ack({ ok: true, room: out, state: view });
      return;
    }
    if (!player.away) return fail("место занято");

    const out = claimSeat(socket, room, player, { name: name || player.name, uid, ip });
    const view = room.core ? viewFor(room, player.seat) : null;
    if (view) socket.emit("game:state", view);
    if (typeof ack === "function") ack({ ok: true, room: out, state: view });
  });

  socket.on("room:leave", (_payload, ack) => {
    leaveRoom(socket);
    if (typeof ack === "function") ack({ ok: true });
  });

  socket.on("disconnect", () => {
    leaveClub(socket);
    const roomId = socketRoom.get(socket.id);
    const room = roomId && rooms.get(roomId);
    const player = room && room.players.get(socket.id);
    /* Партия идёт — место держим за игроком: он мог войти в лифт.
       Из комнаты выкидываем только если играть уже нечего. */
    if (room && player && room.started && room.core) {
      markAway(room, player);
      return;
    }
    if (room && player && !room.started) {
      markHold(room, player);
      return;
    }
    leaveRoom(socket);
  });
});

function leaveRoom(socket) {
  const roomId = socketRoom.get(socket.id);
  if (!roomId) return;
  socketRoom.delete(socket.id);
  const room = rooms.get(roomId);
  if (!room) return;
  room.players.delete(socket.id);
  socket.leave(roomId);
  if (room.players.size === 0) {
    clearWaiting(room);
    rooms.delete(roomId);
    return;
  }
  setWaiting(room);
  if (room.hostId === socket.id) {
    room.hostId = [...room.players.keys()][0];
  }
  // пересчитать seats optional — оставляем как есть
  const out = publicRoom(room);
  io.to(roomId).emit("room:update", out);
}

// чистка пустых/старых комнат (6 часов)
setInterval(() => {
  const now = Date.now();
  for (const [id, r] of rooms) {
    if (r.players.size === 0 || now - r.createdAt > 6 * 3600 * 1000) rooms.delete(id);
  }
}, 60_000).unref?.();

app.use(express.static(PUBLIC));
app.get("/privacy", (_req, res) => {
  res.sendFile(join(PUBLIC, "privacy.html"));
});
if (process.env.TEST_HOOKS === "1") {
  app.post("/__test/plant-sha", (req, res) => {
    const name = normClubName(req.body?.name);
    const pass = String(req.body?.pass || "");
    const club = clubs.get(clubKeyOf(name));
    if (!club) return res.status(404).json({ ok: false });
    const salt = randomBytes(8).toString("hex");
    club.salt = salt;
    club.passHash = hashClubPassSha(pass, salt);
    res.json({ ok: true, hash: club.passHash });
  });
  app.get("/__test/club-hash", (req, res) => {
    const club = clubs.get(clubKeyOf(req.query.name));
    if (!club) return res.status(404).json({ ok: false });
    res.json({ ok: true, hash: club.passHash || "" });
  });
}

app.get(/.*/, (req, res, next) => {
  if (req.path.startsWith("/socket.io")) return next();
  res.sendFile(join(PUBLIC, "index.html"));
});

function serializeClub(c) {
  return {
    name: c.name,
    passHash: c.passHash,
    salt: c.salt || undefined,
    createdAt: c.createdAt,
    tableSeq: c.tableSeq || 0,
    board: c.board || emptyBoard(),
    hostEmail: c.hostEmail || undefined,
  };
}
function serializeRoom(r) {
  const host = [...r.players.values()].find((p) => p.id === r.hostId || p.socketId === r.hostId);
  return {
    id: r.id,
    code: r.code,
    hostSeat: host ? host.seat : 0,
    mode: r.mode,
    maxPlayers: r.maxPlayers,
    target: r.target,
    matchTo: r.matchTo || 1,
    matches: r.matches || null,
    dries: r.dries || null,
    gamesPlayed: r.gamesPlayed || 0,
    started: !!r.started,
    seed: r.seed,
    gameNo: r.gameNo,
    seq: r.seq || 0,
    core: r.core || null,
    createdAt: r.createdAt,
    seenMoves: r.seenMoves ? [...r.seenMoves] : [],
    players: [...r.players.values()].map((p) => ({
      name: p.name,
      seat: p.seat,
      ready: !!p.ready,
      uid: p.uid || undefined,
    })),
  };
}

let snapBusy = false;
let snapQueued = false;
async function saveSnapshot() {
  if (snapBusy) {
    snapQueued = true;
    return;
  }
  snapBusy = true;
  try {
    const data = {
      savedAt: Date.now(),
      clubs: [...clubs.entries()].map(([k, c]) => [k, serializeClub(c)]),
      rooms: [...rooms.entries()].map(([k, r]) => [k, serializeRoom(r)]),
    };
    const tmp = SNAP + ".tmp";
    await writeFile(tmp, JSON.stringify(data));
    await rename(tmp, SNAP);
  } catch (e) {
    console.error("snapshot save failed", e.message);
  } finally {
    snapBusy = false;
    if (snapQueued) {
      snapQueued = false;
      saveSnapshot();
    }
  }
}

function restoreRoom(data) {
  if (!data || !data.id || !data.code) return;
  const players = new Map();
  for (const p of data.players || []) {
    const id = `away:${data.id}:${p.seat}`;
    players.set(id, {
      id,
      name: p.name,
      uid: p.uid || undefined,
      seat: p.seat,
      ready: !!p.ready,
      socketId: id,
      away: true,
      awayAt: Date.now(),
      gaveUpWait: false,
    });
  }
  const host = [...players.values()].find((p) => p.seat === (data.hostSeat ?? 0));
  const room = {
    id: data.id,
    code: String(data.code).toUpperCase(),
    hostId: host?.id,
    mode: data.mode || "1x1",
    maxPlayers: data.maxPlayers || players.size || 2,
    target: data.target || 21,
    matchTo: data.matchTo || 1,
    matches: data.matches || null,
    dries: data.dries || null,
    gamesPlayed: data.gamesPlayed || 0,
    players,
    createdAt: data.createdAt || Date.now(),
    state: null,
    started: !!data.started,
    seed: data.seed,
    gameNo: data.gameNo,
    seq: data.seq || 0,
    core: data.core || null,
    seenMoves: new Set(data.seenMoves || []),
    deadline: null,
    turnTimer: null,
  };
  rooms.set(room.id, room);
  if (!room.started) setWaiting(room);
  else if (room.core && room.core.phase === "playing") {
    for (const p of players.values()) {
      p.gaveUpWait = true;
      p.awayTimer = setTimeout(() => {
        io.to(room.id).emit("player:replaced", { seat: p.seat });
        pushState(room);
        resumeAwayTurns(room);
        armTurn(room);
      }, 400);
    }
  }
}

async function loadSnapshot() {
  try {
    const raw = await readFile(SNAP, "utf8");
    const data = JSON.parse(raw);
    for (const row of data.clubs || []) {
      const c = row[1];
      if (!c?.name || !c?.passHash) continue;
      const k = clubKeyOf(c.name) || clubKeyOf(row[0]);
      if (!k) continue;
      const prev = clubs.get(k);
      if (prev && (prev.createdAt || 0) <= (c.createdAt || Date.now())) continue;
      clubs.set(k, {
        name: c.name,
        passHash: c.passHash,
        salt: c.salt,
        hostId: null,
        members: new Map(),
        tables: [],
        tableSeq: c.tableSeq || 0,
        createdAt: c.createdAt || Date.now(),
        board: c.board && c.board.stats ? c.board : emptyBoard(),
        hostEmail: c.hostEmail || undefined,
      });
    }
    for (const row of data.rooms || []) {
      restoreRoom(row[1] || row);
    }
  } catch (e) {
    if (e && e.code !== "ENOENT") console.error("snapshot load failed", e.message);
  }
}

setInterval(() => saveSnapshot(), 10_000).unref();

await loadSnapshot();
httpServer.listen(PORT, "0.0.0.0", () => {
  console.log(`prodominoes server judge on :${PORT}`);
});
