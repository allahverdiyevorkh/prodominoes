import { createRoot } from "react-dom/client";
import Kozel from "../../src/components/pro-dominoes.jsx";

createRoot(document.getElementById("root")).render(<Kozel />);
