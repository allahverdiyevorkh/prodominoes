import { useEffect, useState } from "react";

const inp = (C, BODY) => ({
  width: "100%",
  fontFamily: BODY,
  fontSize: 16,
  color: C.chalk,
  background: "rgba(0,0,0,.28)",
  border: `1px solid ${C.line}`,
  borderRadius: 10,
  padding: "10px 12px",
  outline: "none",
});

export function ClubAdmin({
  open,
  onClose,
  askPass,
  onCloseAskPass,
  t,
  lang,
  dn,
  C,
  DISPLAY,
  BODY,
  GoldCoin,
  starStore,
  adminSecret,
  savePass,
  setSavePass,
  onCommitPass,
  onUnlock,
  onGrant,
  onWipe,
  onReset,
  onSaveRules,
  onWipeStats,
  grantAmt,
  bank,
  rows,
  rules,
  fmtDay,
}) {
  const [ok, setOk] = useState(false);
  const [pin, setPin] = useState("");
  const [passDraft, setPassDraft] = useState("");
  const [base, setBase] = useState("");
  const [win, setWin] = useState("");
  const [dry, setDry] = useState("");
  const [give, setGive] = useState("");
  const [cap, setCap] = useState("");
  const [saveHit, setSaveHit] = useState(false);
  const [wipeHit, setWipeHit] = useState(false);

  useEffect(() => {
    if (!open && !askPass) {
      setOk(false);
      setPin("");
      setPassDraft("");
      setSaveHit(false);
    }
  }, [open, askPass]);

  useEffect(() => {
    if (!open) return;
    setPin("");
  }, [open]);

  useEffect(() => {
    if (!open || !starStore) return;
    setBase(String(starStore.base ?? 1000));
    setWin(String(rules.win));
    setDry(String(rules.dry));
    setGive(String(rules.giveup));
    setCap(String(rules.brokeCap));
  }, [open, starStore, rules.win, rules.dry, rules.giveup, rules.brokeCap]);

  const style = inp(C, BODY);
  const locale = lang === "en" ? "en-US" : "ru-RU";

  const setPassSheet = askPass ? (
    <div className="absolute inset-0 flex flex-col justify-end" style={{ zIndex: 42 }}>
      <div className="flex-1" style={{ background: "rgba(10,12,15,.72)" }} />
      <div
        style={{
          background: C.slate,
          borderTop: `1px solid ${C.line}`,
          borderTopLeftRadius: 16,
          borderTopRightRadius: 16,
          padding: "18px 16px 22px",
        }}
      >
        <div className="flex items-center justify-between" style={{ marginBottom: 8 }}>
          <span style={{ fontFamily: DISPLAY, fontSize: 22, fontWeight: 800, color: C.chalk }}>
            {t("adminPassTitle")}
          </span>
          <button
            type="button"
            onClick={onCloseAskPass}
            aria-label={t("close")}
            style={{
              width: 32,
              height: 32,
              borderRadius: 99,
              fontFamily: DISPLAY,
              fontSize: 22,
              lineHeight: "30px",
              color: C.chalk,
              border: `1px solid ${C.line}`,
              background: "rgba(0,0,0,.28)",
            }}
          >
            ×
          </button>
        </div>
        <p style={{ fontFamily: BODY, fontSize: 12.5, color: "rgba(233,230,223,.5)", lineHeight: 1.5, marginBottom: 12 }}>
          {t("adminPassExplain")}
        </p>
        <input
          value={passDraft}
          onChange={(e) => setPassDraft(e.target.value.slice(0, 24))}
          onPointerDown={(e) => e.stopPropagation()}
          autoFocus
          autoComplete="off"
          type="password"
          placeholder={t("adminPass")}
          style={style}
        />
        <label className="flex items-center" style={{ gap: 8, marginTop: 10, fontFamily: BODY, fontSize: 12.5, color: "rgba(233,230,223,.6)" }}>
          <input type="checkbox" checked={savePass} onChange={(e) => setSavePass(e.target.checked)} />
          {t("savePassLbl")}
        </label>
        <button
          onClick={() => onCommitPass(passDraft)}
          className="w-full rounded-xl"
          style={{ fontFamily: DISPLAY, fontSize: 19, fontWeight: 800, padding: "11px 0", color: C.night, background: C.brass, marginTop: 12 }}
        >
          {t("save")}
        </button>
      </div>
    </div>
  ) : null;

  if (!open && !askPass) return setPassSheet;

  const sheet = !open ? null : (
    <div className="absolute inset-0 flex flex-col justify-end" style={{ zIndex: 80 }}>
      <div
        className="flex-1"
        onClick={() => {
          onClose();
          setOk(false);
        }}
        style={{ background: "rgba(10,12,15,.72)" }}
      />
      <div
        className="flex flex-col"
        style={{
          background: C.slate,
          borderTop: `1px solid ${C.line}`,
          borderTopLeftRadius: 16,
          borderTopRightRadius: 16,
          maxHeight: "85vh",
          overflow: "hidden",
          position: "relative",
          zIndex: 5,
          pointerEvents: "auto",
        }}
      >
        <div style={{ padding: "14px 16px 8px", flex: "0 0 auto" }}>
          <span style={{ fontFamily: DISPLAY, fontSize: 22, fontWeight: 800, color: C.chalk }}>
            {t("clubAdmin")}
          </span>
        </div>
        <div style={{ overflowY: "auto", flex: 1, minHeight: 0, padding: "0 16px 8px", WebkitOverflowScrolling: "touch" }}>
          {!ok ? (
            !adminSecret ? (
              <>
                <p style={{ fontFamily: BODY, fontSize: 12, color: "rgba(233,230,223,.5)", lineHeight: 1.5, marginBottom: 10 }}>
                  {t("adminSetHint")}
                </p>
                <input
                  value={passDraft}
                  onChange={(e) => setPassDraft(e.target.value.slice(0, 24))}
                  onPointerDown={(e) => e.stopPropagation()}
                  autoFocus
                  autoComplete="off"
                  type="password"
                  placeholder={t("adminPass")}
                  style={style}
                />
                <label className="flex items-center" style={{ gap: 8, marginTop: 10, fontFamily: BODY, fontSize: 12.5, color: "rgba(233,230,223,.6)" }}>
                  <input type="checkbox" checked={savePass} onChange={(e) => setSavePass(e.target.checked)} />
                  {t("savePassLbl")}
                </label>
                <button
                  onClick={() => {
                    if (onCommitPass(passDraft)) setOk(true);
                  }}
                  className="w-full rounded-xl"
                  style={{ fontFamily: DISPLAY, fontSize: 19, fontWeight: 800, padding: "11px 0", color: C.night, background: C.brass, marginTop: 10 }}
                >
                  {t("save")}
                </button>
              </>
            ) : (
              <>
                <p style={{ fontFamily: BODY, fontSize: 12, color: "rgba(233,230,223,.5)", lineHeight: 1.5, marginBottom: 10 }}>
                  {t("adminPassHint")}
                </p>
                <input
                  value={pin}
                  onChange={(e) => setPin(e.target.value.slice(0, 24))}
                  onPointerDown={(e) => e.stopPropagation()}
                  autoFocus
                  autoComplete="off"
                  type="password"
                  placeholder={t("adminPass")}
                  style={style}
                />
                <label className="flex items-center" style={{ gap: 8, marginTop: 10, fontFamily: BODY, fontSize: 12.5, color: "rgba(233,230,223,.6)" }}>
                  <input type="checkbox" checked={savePass} onChange={(e) => setSavePass(e.target.checked)} />
                  {t("savePassLbl")}
                </label>
                <button
                  onClick={() => {
                    if (onUnlock(pin)) {
                      setOk(true);
                      setPin("");
                    }
                  }}
                  className="w-full rounded-xl"
                  style={{ fontFamily: DISPLAY, fontSize: 19, fontWeight: 800, padding: "11px 0", color: C.night, background: C.brass, marginTop: 10 }}
                >
                  {t("enter")}
                </button>
              </>
            )
          ) : (
            <>
              <div className="flex items-center justify-between" style={{ marginBottom: 12 }}>
                <span style={{ fontFamily: BODY, fontSize: 11, letterSpacing: 1.6, textTransform: "uppercase", color: "rgba(233,230,223,.4)" }}>
                  {t("clubBank")}
                </span>
                <span className="flex items-center" style={{ gap: 5, fontFamily: DISPLAY, fontSize: 20, fontWeight: 800, color: C.brass }}>
                  {(bank || 0).toLocaleString(locale)}
                  <GoldCoin size={18} seed={5} />
                </span>
              </div>

              <div style={{ borderTop: `1px solid ${C.line}`, paddingTop: 10 }}>
                <div style={{ fontFamily: BODY, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "rgba(233,230,223,.35)", marginBottom: 6 }}>
                  {t("startStars")}
                </div>
                <div className="flex" style={{ gap: 8 }}>
                  <input
                    value={base}
                    onChange={(e) => setBase(e.target.value.replace(/[^0-9]/g, "").slice(0, 6))}
                    inputMode="numeric"
                    style={{ ...style, flex: 1 }}
                  />
                  <button
                    onClick={() => {
                      const v = Math.max(0, parseInt(base || "0", 10) || 0);
                      onReset(v);
                    }}
                    className="rounded-lg"
                    style={{ fontFamily: BODY, fontSize: 12.5, fontWeight: 600, padding: "0 16px", color: C.night, background: C.brass, flex: "0 0 auto" }}
                  >
                    {t("resetAll")}
                  </button>
                </div>
              </div>

              {onWipeStats ? (
                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setWipeHit(true);
                  }}
                  onPointerUp={(e) => {
                    e.stopPropagation();
                    setWipeHit(false);
                    onWipeStats();
                  }}
                  onPointerCancel={() => setWipeHit(false)}
                  onPointerLeave={() => setWipeHit(false)}
                  onClick={(e) => e.stopPropagation()}
                  className="w-full rounded-xl"
                  style={{
                    fontFamily: DISPLAY,
                    fontSize: 16,
                    fontWeight: 800,
                    padding: "11px 0",
                    marginTop: 12,
                    color: C.night,
                    background: C.brass,
                    touchAction: "manipulation",
                    cursor: "pointer",
                    transform: wipeHit ? "scale(.97) translateY(2px)" : "none",
                    boxShadow: wipeHit ? "inset 0 2px 0 rgba(0,0,0,.25)" : "0 5px 0 rgba(90,64,20,.85), 0 8px 18px rgba(0,0,0,.35)",
                    transition: "transform .08s ease, box-shadow .08s ease",
                  }}
                >
                  {t("resetStats")}
                </button>
              ) : null}

              <div style={{ borderTop: `1px solid ${C.line}`, marginTop: 12, paddingTop: 10 }}>
                <div style={{ fontFamily: BODY, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "rgba(233,230,223,.35)", marginBottom: 8 }}>
                  {t("matchStarsLbl")}
                </div>
                {[
                  [t("winLbl"), win, setWin],
                  [t("shutoutExtra"), dry, setDry],
                  [t("surrenderLbl"), give, setGive],
                  [t("brokeCap"), cap, setCap],
                ].map(([lab, val, set]) => (
                  <div key={lab} className="flex items-center" style={{ gap: 8, marginBottom: 6 }}>
                    <span style={{ fontFamily: BODY, fontSize: 12.5, color: "rgba(233,230,223,.6)", flex: 1 }}>{lab}</span>
                    <input
                      value={val}
                      onChange={(e) => set(e.target.value.replace(/[^0-9]/g, "").slice(0, 5))}
                      inputMode="numeric"
                      style={{ ...style, width: 72, flex: "0 0 auto", padding: "8px 10px", textAlign: "right" }}
                    />
                  </div>
                ))}
                <p style={{ fontFamily: BODY, fontSize: 10.5, color: "rgba(233,230,223,.38)", lineHeight: 1.4, margin: "4px 0 0" }}>
                  {t("grantHint", grantAmt, rules.brokeCap)}
                </p>
              </div>

              <div style={{ fontFamily: BODY, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "rgba(233,230,223,.35)", margin: "14px 0 6px" }}>
                {t("players")}
              </div>
              <div
                className="club-stats"
                style={{
                  borderRadius: 12,
                  border: "1px solid rgba(212,168,83,.22)",
                  background: "rgba(0,0,0,.22)",
                  overflowY: "auto",
                  maxHeight: 240,
                  marginBottom: 4,
                }}
              >
                {(rows || []).map((r, i) => {
                  const empty = r.stars <= 0;
                  const hard = Math.max(grantAmt, rules.brokeCap || 200);
                  const lastAdd = (starStore?.log || []).find((e) => e.admin && e.name === r.name && e.reset === undefined && !e.wipe);
                  const canAdd = empty || (lastAdd && r.stars > 0 && r.stars < hard);
                  return (
                    <div
                      key={r.name}
                      className="flex items-center"
                      style={{
                        gap: 8,
                        padding: "8px 10px",
                        borderTop: i ? "1px solid rgba(255,255,255,.05)" : "none",
                      }}
                    >
                      <span style={{ flex: 1, minWidth: 0, opacity: empty ? 0.45 : 1 }}>
                        <span style={{ display: "block", fontFamily: BODY, fontSize: 13.5, fontWeight: 600, color: C.chalk, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {dn(r.name)}
                        </span>
                        {lastAdd ? (
                          <span style={{ display: "block", fontFamily: BODY, fontSize: 10, color: "rgba(233,230,223,.4)", marginTop: 1 }}>
                            {fmtDay(lastAdd.t, lang)} · {lastAdd.delta > 0 ? "+" : ""}{lastAdd.delta}
                          </span>
                        ) : null}
                      </span>
                      {canAdd ? (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onGrant(r.name, grantAmt);
                          }}
                          aria-label="+"
                          style={{
                            width: 32,
                            height: 32,
                            borderRadius: 99,
                            flex: "0 0 auto",
                            fontFamily: DISPLAY,
                            fontSize: 22,
                            fontWeight: 800,
                            lineHeight: "30px",
                            color: C.night,
                            background: C.brass,
                            boxShadow: "0 0 10px rgba(212,168,83,.35)",
                          }}
                        >
                          +
                        </button>
                      ) : r.stars > 0 ? (
                        <button
                          type="button"
                          onClick={() => onWipe(r.name)}
                          style={{
                            flex: "0 0 auto",
                            fontFamily: BODY,
                            fontSize: 11,
                            fontWeight: 700,
                            padding: "6px 8px",
                            color: C.theirs,
                            border: "1px solid rgba(197,107,82,.5)",
                            borderRadius: 8,
                          }}
                        >
                          {t("zero")}
                        </button>
                      ) : null}
                      <span
                        className="flex items-center"
                        style={{ width: 64, justifyContent: "flex-end", gap: 3, fontFamily: DISPLAY, fontSize: 17, fontWeight: 800, color: C.brass }}
                      >
                        {r.stars}
                        <GoldCoin size={13} seed={i + 2} />
                      </span>
                    </div>
                  );
                })}
              </div>

              {(starStore?.log || []).length > 0 && (
                <div style={{ borderTop: `1px solid ${C.line}`, marginTop: 12, paddingTop: 10 }}>
                  <div style={{ fontFamily: BODY, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "rgba(233,230,223,.35)", marginBottom: 6 }}>
                    {t("latest")}
                  </div>
                  <div className="club-stats" style={{ maxHeight: 128, overflowY: "auto", WebkitOverflowScrolling: "touch" }}>
                    {(starStore.log || [])
                      .reduce((acc, e) => {
                        if (e.admin && e.name && e.reset === undefined && !e.wipe) {
                          const d = new Date(e.t);
                          const k = `${e.name}|${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
                          const hit = acc.find((x) => x._k === k);
                          if (hit) {
                            hit.delta += e.delta;
                            return acc;
                          }
                          acc.push({ ...e, _k: k });
                          return acc;
                        }
                        acc.push(e);
                        return acc;
                      }, [])
                      .map((e, i) => (
                        <div key={i} style={{ fontFamily: BODY, fontSize: 11.5, color: "rgba(233,230,223,.5)", padding: "4px 0", borderTop: i ? "1px solid rgba(255,255,255,.05)" : "none" }}>
                          {e.reset !== undefined
                            ? t("starResetLog", fmtDay(e.t, lang), e.reset)
                            : e.admin
                              ? `${fmtDay(e.t, lang)} · ${dn(e.name)} ${e.delta > 0 ? "+" : ""}${e.delta}`
                              : `${fmtDay(e.t, lang)} · ${(e.winners || []).map(dn).join(", ")} +${e.stake || 0}${e.dry ? t("shutoutTag") : ""}${e.surrender ? t("surrenderTag") : ""}`}
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
        {ok ? (
          <div style={{ padding: "10px 16px calc(14px + env(safe-area-inset-bottom, 0px))", borderTop: `1px solid ${C.line}`, flex: "0 0 auto", background: C.slate, zIndex: 8, pointerEvents: "auto" }}>
            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                setSaveHit(true);
              }}
              onPointerUp={(e) => {
                e.stopPropagation();
                setSaveHit(false);
                onSaveRules({ win, dry, giveup: give, brokeCap: cap });
                setOk(false);
                onClose();
              }}
              onPointerCancel={() => setSaveHit(false)}
              onPointerLeave={() => setSaveHit(false)}
              onClick={(e) => e.stopPropagation()}
              className="w-full rounded-xl"
              style={{
                fontFamily: DISPLAY,
                fontSize: 20,
                fontWeight: 800,
                padding: "14px 0",
                color: C.night,
                background: C.brass,
                position: "relative",
                zIndex: 8,
                pointerEvents: "auto",
                touchAction: "manipulation",
                cursor: "pointer",
                transform: saveHit ? "scale(.97) translateY(2px)" : "none",
                boxShadow: saveHit ? "inset 0 2px 0 rgba(0,0,0,.25)" : "0 5px 0 rgba(90,64,20,.85), 0 8px 18px rgba(0,0,0,.35)",
                transition: "transform .08s ease, box-shadow .08s ease",
              }}
            >
              {t("save")}
            </button>
          </div>
        ) : null}
      </div>
    </div>
  );

  return (
    <>
      {setPassSheet}
      {sheet}
    </>
  );
}
