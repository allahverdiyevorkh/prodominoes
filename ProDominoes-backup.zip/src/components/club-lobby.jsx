function ClubPresence({ t, dn, C, BODY, DISPLAY, GoldCoin, RankRow, roster, invites, freeSeats, onInvite, goldOf, rateOf }) {
  const list = [...(roster || [])].sort((a, b) => {
    const order = { free: 0, playing: 1, away: 2 };
    return (order[a.status] ?? 3) - (order[b.status] ?? 3) || a.name.localeCompare(b.name);
  });
  return (
    <div style={{ borderTop: `1px solid ${C.line}`, paddingTop: 10, marginTop: 8 }}>
      <div className="flex items-baseline justify-between" style={{ marginBottom: 7 }}>
        <span style={{ fontFamily: BODY, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "rgba(233,230,223,.52)" }}>
          {t("whoInClub")}
        </span>
        <span style={{ fontFamily: BODY, fontSize: 10.5, color: "rgba(233,230,223,.5)" }}>
          {t("onlineNow", list.length)}
        </span>
      </div>
      <div style={{ maxHeight: 220, overflowY: "auto" }}>
        {list.map((p) => {
          const inv = invites[p.name];
          const busy = p.status !== "free";
          const can = !busy && !inv && freeSeats > 0;
          return (
            <div
              key={p.name}
              className="flex items-center"
              style={{
                gap: 8,
                padding: "7px 8px",
                marginBottom: 5,
                borderRadius: 9,
                background: "rgba(0,0,0,.24)",
                border: `1px solid ${inv === "joined" ? C.ours : C.line}`,
              }}
            >
              <span
                aria-hidden
                style={{
                  width: 7,
                  height: 7,
                  borderRadius: 99,
                  flex: "0 0 auto",
                  background: p.status === "free" ? C.ours : p.status === "playing" ? C.brass : "rgba(233,230,223,.3)",
                }}
              />
              <span style={{ fontFamily: BODY, fontSize: 13, color: C.chalk, minWidth: 0, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {dn(p.name)}
              </span>
              <RankRow rating={rateOf(p.name)} size={8} />
              <button
                type="button"
                disabled={!can}
                onClick={() => can && onInvite(p.name)}
                className="rounded-full"
                style={{
                  flex: "0 0 auto",
                  fontFamily: BODY,
                  fontSize: 10.5,
                  fontWeight: 700,
                  padding: "5px 9px",
                  whiteSpace: "nowrap",
                  color: inv === "joined" ? C.ours : inv === "declined" ? "rgba(233,230,223,.45)" : can ? C.night : "rgba(233,230,223,.35)",
                  background: can ? C.brass : "transparent",
                  border: `1px solid ${can ? C.brass : C.line}`,
                }}
              >
                {inv === "joined"
                  ? t("invJoined")
                  : inv === "declined"
                    ? t("invDeclined")
                    : inv
                      ? t("invSent")
                      : busy
                        ? t(p.status === "playing" ? "atTable" : "away")
                        : t("invite")}
              </button>
            </div>
          );
        })}
      </div>
      <p style={{ fontFamily: BODY, fontSize: 10, color: "rgba(233,230,223,.5)", marginTop: 4, lineHeight: 1.45 }}>
        {t("presenceLocal")}
      </p>
    </div>
  );
}

export function ClubLobby({
  t,
  lang,
  dn,
  C,
  DISPLAY,
  BODY,
  Shell,
  GoldCoin,
  CupBadge,
  RankRow,
  VsBoard,
  OptRow,
  MATCH_OPTIONS,
  room,
  clubGate,
  clubMake,
  clubKind,
  clubTable,
  clubPass,
  clubContact,
  clubSaved,
  roomCode,
  roomWait,
  savePass,
  adminSecret,
  adminLayer,
  countdown,
  flyRoom,
  roomsRef,
  yearFlash,
  stats,
  starStore,
  vsBook,
  rating,
  names,
  mode,
  target,
  matchTo,
  brokeInClub,
  setClubGate,
  setClubMake,
  setClubKind,
  setClubPass,
  setClubContact,
  setClubSaved,
  setRoomCode,
  setSavePass,
  setAdminOpen,
  setScreen,
  setMatchTo,
  setTarget,
  setFlyRoom,
  setYearFlash,
  setRoom,
  createRoom,
  joinRoom,
  openClubTable,
  cancelClubTable,
  joinExistingTable,
  leaveClubTable,
  sitAt,
  toggleReady,
  inviteToTable,
  invites,
  roster,
  goldOf,
  refuseNoStars,
  persistClub,
  roomBlocks,
  tint,
  tableDetails,
  champOf,
  thisWeekRange,
  thisMonthRange,
  thisYearRange,
  statRows,
  starBank,
  pairSides,
  rateOfName,
  SFX
}) {
    const seatsSrc = clubTable?.seats || [];
    const meSeat = seatsSrc.findIndex((x) => x && x.me);
    const iAmReady = meSeat >= 0 && seatsSrc[meSeat]?.ready;
    const seatedCount = seatsSrc.filter(Boolean).length;
    const canStart = seatedCount >= 2;
    const inp = {
      width: "100%",
      fontFamily: BODY,
      fontSize: 16,
      color: C.chalk,
      background: "rgba(0,0,0,.28)",
      border: `1px solid ${C.line}`,
      borderRadius: 10,
      padding: "12px 14px",
      outline: "none",
    };
    const playingNow = (roster && roster.length)
      ? roster.length
      : (room?.tables || []).reduce((a, tb) => a + (tb.taken || 0), 0);
    const modeLabel = (m) =>
      m === "tourney" ? t("tournament") : m === "2x2" ? t("table22") : m === "heads" ? t("tableHeads") : t("tableThree");
    const weekChamp = champOf(stats, thisWeekRange());
    const monthChamp = champOf(stats, thisMonthRange());
    const yearChamp = champOf(stats, thisYearRange());
    const rows = statRows(stats, room, starStore);
    const goldBank = starBank(starStore, rows.map((r) => r.name));
    const clubBoard = (
      <div style={{ marginTop: 14, paddingTop: 12, borderTop: `1px solid ${C.line}` }}>
        <div style={{ fontFamily: BODY, fontSize: 10, letterSpacing: 2.2, textTransform: "uppercase", color: "rgba(233,230,223,.38)", marginBottom: 8 }}>
          {t("champions")}
        </div>
        <div className="flex" style={{ gap: 8, marginBottom: 14 }}>
          {[
            [t("week"), weekChamp],
            [t("month"), monthChamp],
            [t("year"), yearChamp, true],
          ].map(([label, name, year]) => (
              <div
                key={label}
                className="flex-1 flex flex-col items-center"
                style={{
                  padding: "8px 4px 8px",
                  borderRadius: 10,
                  background: year ? "rgba(198,154,70,.1)" : "rgba(0,0,0,.22)",
                  border: `1px solid ${year ? "rgba(198,154,70,.5)" : C.line}`,
                }}
              >
                <span style={{ fontFamily: BODY, fontSize: 9, letterSpacing: 1.4, textTransform: "uppercase", color: year ? C.brass : "rgba(233,230,223,.4)" }}>{label}</span>
                <span style={{ fontFamily: BODY, fontSize: 13, fontWeight: 700, color: C.chalk, marginTop: 5 }}>{name ? dn(name) : "—"}</span>
              </div>
            ))}
        </div>
        <div style={{ position: "relative" }}>
        <div
          className="club-stats"
          style={{
            borderRadius: 12,
            overflowY: "auto",
            maxHeight: 260,
            border: "1px solid rgba(212,168,83,.22)",
            background: "linear-gradient(180deg, rgba(28,22,14,.45) 0%, rgba(0,0,0,.28) 100%)",
            boxShadow: "inset 0 1px 0 rgba(232,210,150,.08)",
          }}
        >
          <div
            className="flex items-center"
            style={{
              padding: "8px 10px",
              background: "rgba(18,16,12,.94)",
              borderBottom: "1px solid rgba(212,168,83,.18)",
              fontFamily: BODY,
              fontSize: 9,
              letterSpacing: 1.4,
              textTransform: "uppercase",
              color: "rgba(233,230,223,.45)",
              position: "sticky",
              top: 0,
              zIndex: 1,
            }}
          >
            <span style={{ width: 22 }}>#</span>
            <span style={{ flex: 1 }}>{t("player")}</span>
            <span style={{ width: 36, textAlign: "right" }}>{t("statG")}</span>
            <span style={{ width: 36, textAlign: "right" }}>{t("statW")}</span>
            <span style={{ width: 36, textAlign: "right" }}>{t("statS")}</span>
            <span className="flex items-center justify-end" style={{ width: 60, color: C.brass }}>
              <GoldCoin size={16} seed={7} />
            </span>
          </div>
          {rows.map((r, i) => {
            const me = r.name === "Вы";
            const dim = r.stars <= 0;
            const podium = dim ? "rgba(233,230,223,.22)" : i === 0 ? "#E4BE6A" : i === 1 ? "#C5CDD8" : i === 2 ? "#C0895A" : "rgba(233,230,223,.4)";
            return (
            <div
              key={r.name}
              className="flex items-center"
              style={{
                padding: "8px 10px",
                background: me ? "rgba(198,154,70,.12)" : i === 0 ? "rgba(198,154,70,.08)" : i % 2 ? "rgba(255,255,255,.025)" : "transparent",
                borderTop: i ? "1px solid rgba(255,255,255,.04)" : "none",
                boxShadow: me ? "inset 2px 0 0 #D4A853" : "none",
                fontFamily: BODY,
                fontSize: 13,
                color: C.chalk,
                opacity: dim ? 0.38 : 1,
                filter: dim ? "grayscale(.35)" : "none",
              }}
            >
              <span style={{ width: 22, fontFamily: DISPLAY, fontWeight: 800, color: podium, fontSize: 13 }}>
                {i + 1}
              </span>
              <span className="flex items-center" style={{ flex: 1, gap: 6, minWidth: 0, fontWeight: 500 }}>
                <RankRow rating={me ? rating : rateOfName(r.name, rating)} size={11} />
                <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{dn(r.name)}</span>
                {dim ? (
                  <span style={{ fontFamily: BODY, fontSize: 9, letterSpacing: 0.6, textTransform: "uppercase", color: "rgba(233,230,223,.45)", flex: "0 0 auto" }}>
                    {t("cantPlay")}
                  </span>
                ) : null}
                {r.yearStars > 0 ? <CupBadge n={r.yearStars} years={r.years} /> : null}
              </span>
              <span style={{ width: 36, textAlign: "right", color: "rgba(233,230,223,.55)", fontVariantNumeric: "tabular-nums" }}>{r.played}</span>
              <span style={{ width: 36, textAlign: "right", color: C.ours, fontVariantNumeric: "tabular-nums" }}>{r.wins}</span>
              <span style={{ width: 36, textAlign: "right", color: C.theirs, fontVariantNumeric: "tabular-nums" }}>{r.dry}</span>
              <span style={{ width: 60, textAlign: "right", color: C.brass, fontWeight: 800, fontFamily: DISPLAY, fontSize: 13, fontVariantNumeric: "tabular-nums" }}>
                {r.stars}
              </span>
            </div>
            );
          })}
        </div>
        <div
          style={{
            position: "absolute",
            left: 1,
            right: 1,
            bottom: 1,
            height: 32,
            borderBottomLeftRadius: 12,
            borderBottomRightRadius: 12,
            background: "linear-gradient(180deg, transparent, rgba(12,14,18,.92))",
            pointerEvents: "none",
          }}
        />
        </div>
        <div className="flex items-center justify-between" style={{ marginTop: 8 }}>
          <span style={{ fontFamily: BODY, fontSize: 11, color: "rgba(233,230,223,.42)" }}>
            {t("clubBank")}
          </span>
          <span className="flex items-center" style={{ gap: 5, fontFamily: DISPLAY, fontSize: 17, fontWeight: 800, color: C.brass }}>
            {goldBank.toLocaleString(lang === "en" ? "en-US" : "ru-RU")}
            <GoldCoin size={17} seed={3} />
          </span>
        </div>
        <p style={{ fontFamily: BODY, fontSize: 10.5, color: "rgba(233,230,223,.3)", marginTop: 4, lineHeight: 1.45 }}>
          {t("starsMove")}
        </p>
      </div>
    );
    return (
      <Shell>
        <div
          className="flex flex-col h-full"
          style={{
            maxWidth: 440,
            margin: "0 auto",
            padding: "14px 16px",
            gap: 12,
            overflowY: "auto",
            ...(!room ? { justifyContent: "center" } : {}),
          }}
        >
          {room && (
            <div className="flex items-baseline justify-between" style={{ gap: 8 }}>
              <span style={{ fontFamily: DISPLAY, fontSize: 26, fontWeight: 800, color: C.chalk, lineHeight: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {room.name || room.code}
              </span>
              <span className="flex items-center" style={{ gap: 8, flex: "0 0 auto" }}>
                <span style={{ fontFamily: BODY, fontSize: 12, color: "rgba(233,230,223,.45)" }}>
                  {t("inClub", playingNow)}
                </span>
                <button
                  type="button"
                  onClick={() => setAdminOpen(true)}
                  className="rounded-full"
                  style={{
                    fontFamily: BODY,
                    fontSize: 10,
                    fontWeight: 700,
                    letterSpacing: 1.4,
                    padding: "5px 10px",
                    color: C.brass,
                    border: `1px solid rgba(212,168,83,.5)`,
                    background: "rgba(212,168,83,.1)",
                  }}
                >
                  {t("admin")}
                </button>
              </span>
            </div>
          )}

          {room && brokeInClub && (
            <div
              className="rounded-xl"
              style={{ padding: "10px 12px", border: `1px solid rgba(197,107,82,.5)`, background: "rgba(197,107,82,.1)" }}
            >
              <span style={{ fontFamily: BODY, fontSize: 12, color: C.chalk, lineHeight: 1.45 }}>
                {t("outOfStars")}
              </span>
            </div>
          )}

          {yearFlash && (
            <div
              className="flex items-center justify-between rounded-xl"
              style={{ padding: "10px 12px", border: `1px solid rgba(212,168,83,.5)`, background: "rgba(212,168,83,.1)", gap: 8 }}
            >
              <span style={{ fontFamily: BODY, fontSize: 12, color: C.chalk, lineHeight: 1.4 }}>
                {t("yearChampFlash", yearFlash.year, dn(yearFlash.name))}
              </span>
              <button
                type="button"
                onClick={() => setYearFlash(null)}
                style={{ fontFamily: BODY, fontSize: 12, color: "rgba(233,230,223,.5)", flex: "0 0 auto" }}
              >
                {t("ok")}
              </button>
            </div>
          )}

          {!room ? (
            !clubGate ? (
              <div className="flex" style={{ gap: 10 }}>
                {[
                  ["create", t("createClub")],
                  ["join", t("enter")],
                ].map(([v, l]) => (
                  <button
                    key={v}
                    onClick={() => setClubGate(v)}
                    className="flex-1 rounded-xl"
                    style={{
                      fontFamily: DISPLAY,
                      fontSize: 17,
                      fontWeight: 800,
                      padding: "14px 0",
                      color: C.night,
                      background: `linear-gradient(180deg,#E4BE6A,${C.brass})`,
                    }}
                  >
                    {l}
                  </button>
                ))}
              </div>
            ) : (
              <>
                <input value={roomCode} onChange={(e) => setRoomCode(e.target.value.slice(0, 20))} placeholder={t("clubName")} style={inp} />
                <input type="password" value={clubPass} onChange={(e) => setClubPass(e.target.value.slice(0, 24))} placeholder={t("clubPassword")} style={inp} />
                {clubGate === "create" && (
                  <input value={clubContact} onChange={(e) => setClubContact(e.target.value.slice(0, 40))} placeholder={t("emailOrPhone")} style={inp} />
                )}
                <label className="flex items-center" style={{ gap: 8, fontFamily: BODY, fontSize: 13, color: "rgba(233,230,223,.6)" }}>
                  <input type="checkbox" checked={savePass} onChange={(e) => setSavePass(e.target.checked)} />
                  {t("savePasswords")}
                </label>
                <button
                  onClick={clubGate === "create" ? createRoom : joinRoom}
                  className="w-full rounded-xl"
                  style={{ fontFamily: DISPLAY, fontSize: 20, fontWeight: 800, padding: "12px 0", color: C.night, background: C.brass }}
                >
                  {clubGate === "create" ? t("createClub") : t("enter")}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    persistClub({ name: roomCode.trim(), pass: clubPass, contact: clubContact, adminPass: adminSecret });
                    setClubSaved(true);
                    setSavePass(true);
                  }}
                  className="w-full rounded-lg"
                  style={{ fontFamily: BODY, fontSize: 13, fontWeight: 600, padding: "10px 0", color: C.chalk, border: `1px solid ${C.line}` }}
                >
                  {clubSaved ? t("savedLbl") : t("rememberMe")}
                </button>
              </>
            )
          ) : clubTable?.mode === "tourney" ? (
            <>
              <div style={{ fontFamily: BODY, fontSize: 12, color: "rgba(233,230,223,.5)" }}>
                {t("tournament")} · {clubTable.people.length}/{clubTable.need}
              </div>
              {(clubTable.people || []).map((p, i) => (
                <div
                  key={p.name + i}
                  className="flex justify-between rounded-lg"
                  style={{
                    padding: "10px 12px",
                    border: `1px solid ${C.line}`,
                    opacity: p.out ? 0.35 : 1,
                    color: p.me ? C.brass : C.chalk,
                    fontFamily: BODY,
                    fontSize: 14,
                  }}
                >
                  <span>{dn(p.name)}</span>
                  <span style={{ color: "rgba(233,230,223,.4)", fontSize: 12 }}>{p.out ? t("eliminated") : t("inPlay")}</span>
                </div>
              ))}
            </>
          ) : clubTable?.seats ? (
            <>
              <div className="flex items-baseline justify-between" style={{ gap: 8 }}>
                <span style={{ fontFamily: DISPLAY, fontSize: 18, fontWeight: 800, color: C.chalk }}>
                  #{clubTable.no} · {modeLabel(clubTable.mode)}
                </span>
                <span style={{ fontFamily: BODY, fontSize: 11.5, color: "rgba(233,230,223,.5)" }}>
                  {tableDetails({ target, matchTo, taken: clubTable.seats.filter(Boolean).length, need: clubTable.need }, lang)}
                </span>
              </div>
              <div
                className="flex"
                style={{
                  gap: clubTable.mode === "three" ? 6 : 10,
                  flexDirection: "row",
                  opacity: countdown !== null ? 0.5 : 1,
                  transition: "opacity .35s ease",
                }}
              >
                {roomBlocks(clubTable.mode, t).map((block, bi) => (
                  <div
                    key={bi}
                    className="flex-1"
                    style={{
                      minWidth: 0,
                      border: `1px solid ${tint(block.color, 0.45)}`,
                      background: tint(block.color, 0.08),
                      borderRadius: 12,
                      padding: clubTable.mode === "three" ? "5px 6px" : 9,
                    }}
                  >
                    <div style={{ fontFamily: BODY, fontSize: clubTable.mode === "three" ? 8 : 10, letterSpacing: 1.4, textTransform: "uppercase", color: block.color, marginBottom: clubTable.mode === "three" ? 4 : 6, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {block.label}
                    </div>
                    {block.slots.map((slot) => {
                      const p = clubTable.seats[slot];
                      return (
                        <button
                          key={slot}
                          onClick={() => sitAt(slot)}
                          className="w-full rounded-lg"
                          style={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            gap: 6,
                            width: "100%",
                            textAlign: "left",
                            padding: clubTable.mode === "three" ? "6px 7px" : "9px 10px",
                            marginBottom: clubTable.mode === "three" ? 0 : 6,
                            background: p ? "rgba(0,0,0,.28)" : "rgba(255,255,255,.03)",
                            border: `1px ${p ? "solid" : "dashed"} ${p && p.me ? C.brass : p && p.ready ? C.ours : C.line}`,
                          }}
                        >
                          <span
                            style={{
                              fontFamily: BODY,
                              fontSize: clubTable.mode === "three" ? 11 : 13,
                              color: p ? C.chalk : "rgba(233,230,223,.3)",
                              fontWeight: p && p.me ? 600 : 400,
                              minWidth: 0,
                              flex: 1,
                              overflow: "hidden",
                              textOverflow: "ellipsis",
                              whiteSpace: "nowrap",
                            }}
                          >
                            {p ? dn(p.name) : t("free")}
                          </span>
                          {p && (
                            <span
                              style={{
                                fontFamily: BODY,
                                fontSize: clubTable.mode === "three" ? 9 : 11,
                                fontWeight: 700,
                                letterSpacing: 0.4,
                                color: p.ready ? C.ours : "rgba(233,230,223,.38)",
                                flex: "0 0 auto",
                              }}
                            >
                              {p.ready ? t("readyCaps") : t("waitOne")}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                ))}
              </div>
              {countdown === null ? (() => {
                const sides = pairSides(clubTable.seats, clubTable.mode);
                return (
              <VsBoard
                names={sides.foes}
                partner={sides.partner}
                pair={clubTable.mode === "2x2"}
                book={vsBook}
                title={t("vsBoard")}
                dryLbl={(n) => t("dryShort", n)}
              />
                );
              })() : null}
              <button
                onClick={toggleReady}
                disabled={meSeat < 0 || !canStart}
                className="w-full rounded-xl"
                style={{
                  fontFamily: DISPLAY,
                  fontSize: 22,
                  fontWeight: 800,
                  padding: "12px 0",
                  color: iAmReady ? C.chalk : C.night,
                  background: meSeat < 0 || !canStart ? "rgba(198,154,70,.3)" : iAmReady ? "rgba(94,156,136,.25)" : C.brass,
                }}
              >
                {meSeat < 0 ? t("takeSeat") : t("readyCaps")}
              </button>
              {countdown !== null && (
                <div style={{ textAlign: "center", marginTop: 4 }}>
                  <div style={{ fontFamily: BODY, fontSize: 11, letterSpacing: 2.4, textTransform: "uppercase", color: "rgba(233,230,223,.4)", marginBottom: 6 }}>
                    {t("startsIn")}
                  </div>
                  <div
                    key={countdown}
                    style={{
                      fontFamily: DISPLAY,
                      fontSize: clubTable.mode === "three" ? 48 : 64,
                      fontWeight: 800,
                      color: C.chalk,
                      lineHeight: 1,
                      animation: "countBeat .9s ease-out both",
                    }}
                  >
                    {countdown}
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              <div
                ref={roomsRef}
                style={{ fontFamily: BODY, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "rgba(233,230,223,.35)" }}
              >
                {t("rooms")}
              </div>
              {(room.tables || []).map((tbl) => {
                const full = tbl.taken >= tbl.need;
                return (
                <div
                  key={tbl.no}
                  className="w-full flex items-center rounded-lg"
                  style={{
                    padding: "8px 10px",
                    gap: 8,
                    border: `1px solid ${C.line}`,
                    background: full ? "rgba(0,0,0,.12)" : "rgba(0,0,0,.18)",
                    opacity: full && !tbl.created ? 0.72 : 1,
                  }}
                >
                  <button
                    type="button"
                    onClick={() => {
                      if (full || tbl.created) return;
                      if (brokeInClub) return refuseNoStars();
                      joinExistingTable(tbl);
                    }}
                    className="flex-1 flex items-center"
                    style={{ minWidth: 0, textAlign: "left", background: "transparent", border: "none", padding: 0, gap: 8, cursor: full || tbl.created ? "default" : "pointer" }}
                  >
                    <span style={{ fontFamily: DISPLAY, fontSize: 16, fontWeight: 800, color: C.chalk, flex: "0 0 auto" }}>#{tbl.no}</span>
                    <span style={{ flex: 1, minWidth: 0, overflow: "hidden" }}>
                      <span style={{ display: "block", fontFamily: BODY, fontSize: 12, color: "rgba(233,230,223,.65)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {modeLabel(tbl.mode)}
                      </span>
                      <span style={{ display: "block", fontFamily: BODY, fontSize: 10.5, color: "rgba(233,230,223,.4)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {tableDetails(tbl, lang)}
                        {(tbl.sitting || []).length ? ` · ${(tbl.sitting || []).join(" · ")}` : ""}
                      </span>
                    </span>
                    <span style={{ fontFamily: BODY, fontSize: 12, color: C.chalk, flex: "0 0 auto" }}>{tbl.taken}/{tbl.need}</span>
                    <span
                      style={{
                        fontFamily: BODY,
                        fontSize: 10,
                        fontWeight: 700,
                        letterSpacing: 0.4,
                        color: full ? C.ours : "rgba(233,230,223,.55)",
                        background: full ? "rgba(107,175,152,.16)" : "rgba(255,255,255,.06)",
                        borderRadius: 99,
                        padding: "4px 8px",
                        flex: "0 0 auto",
                      }}
                    >
                      {roomWait && roomWait.no === tbl.no
                        ? `${roomWait.left}`
                        : full
                          ? t("playingMany")
                          : t("waitingMany")}
                    </span>
                  </button>
                  {tbl.created && (
                    <button
                      type="button"
                      onClick={() => cancelClubTable(tbl.no)}
                      style={{
                        flex: "0 0 auto",
                        fontFamily: BODY,
                        fontSize: 11,
                        fontWeight: 700,
                        color: C.theirs,
                        border: "1px solid rgba(192,103,76,.45)",
                        borderRadius: 8,
                        padding: "6px 8px",
                      }}
                    >
                      {t("cancel")}
                    </button>
                  )}
                </div>
                );
              })}
              {(() => {
                const mineTbl = (room.tables || []).find((tb) => tb.created && !tb.opened);
                if (!mineTbl) return null;
                const free = Math.max(0, mineTbl.need - (mineTbl.taken || 1));
                return (
                  <ClubPresence
                    t={t}
                    dn={dn}
                    C={C}
                    BODY={BODY}
                    DISPLAY={DISPLAY}
                    GoldCoin={GoldCoin}
                    RankRow={RankRow}
                    roster={roster}
                    invites={invites || {}}
                    freeSeats={free}
                    onInvite={inviteToTable}
                    goldOf={goldOf || (() => 0)}
                    rateOf={(n) => rateOfName(n, rating)}
                  />
                );
              })()}
              <button
                type="button"
                onClick={(e) => {
                  if ((room?.tables || []).some((t) => t.created) || flyRoom) return;
                  if (brokeInClub) {
                    setClubMake(false);
                    refuseNoStars();
                    return;
                  }
                  if (!clubMake) {
                    setClubMake(true);
                    return;
                  }
                  if (!clubKind) {
                    setClubMake(false);
                    return;
                  }
                  const from = e.currentTarget.getBoundingClientRect();
                  const dest = roomsRef.current?.getBoundingClientRect();
                  const x0 = from.left + from.width / 2;
                  const y0 = from.top + from.height / 2;
                  const x1 = dest ? dest.left + Math.min(48, dest.width * 0.18) : x0;
                  const y1 = dest ? dest.top + 18 : y0 - 80;
                  const label = clubKind === "2x2" ? t("table22") : clubKind === "three" ? t("tableThree") : t("tableHeads");
                  SFX.comet();
                  setFlyRoom({ kind: clubKind, label, x0, y0, x1, y1 });
                  window.setTimeout(() => {
                    SFX.cometLand();
                    openClubTable(clubKind);
                    setFlyRoom(null);
                  }, 900);
                }}
                className={`w-full rounded-lg${clubMake && clubKind ? " glow-play" : ""}`}
                style={{
                  position: "relative",
                  overflow: clubMake && clubKind ? "visible" : "hidden",
                  zIndex: 0,
                  fontFamily: BODY,
                  fontSize: 13,
                  fontWeight: 700,
                  padding: "10px 0",
                  minHeight: 42,
                  color: clubMake && clubKind ? C.night : C.chalk,
                  opacity: brokeInClub || (room?.tables || []).some((t) => t.created) ? 0.35 : 1,
                  border: clubMake && clubKind ? "none" : `1.5px solid ${C.brass}`,
                  boxShadow: clubMake && clubKind ? "none" : "0 0 0 1px rgba(212,168,83,.25), inset 0 0 0 1px rgba(247,223,156,.15)",
                  background: clubMake && clubKind ? `linear-gradient(180deg,#E4BE6A,${C.brass})` : "transparent",
                }}
              >
                <span style={{ position: "relative", zIndex: 1 }}>{t("createRoomBtn")}</span>
              </button>
              {clubMake && (
                <div
                  style={{
                    borderRadius: 14,
                    border: "1px solid rgba(212,168,83,.28)",
                    background: "linear-gradient(180deg,#22262E 0%,#16191F 100%)",
                    boxShadow: "inset 0 1px 0 rgba(255,255,255,.05), 0 14px 32px rgba(0,0,0,.4)",
                    padding: "14px 12px 12px",
                    display: "flex",
                    flexDirection: "column",
                    gap: 14,
                  }}
                >
                  <div style={{ fontFamily: BODY, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "rgba(233,230,223,.4)" }}>
                    {t("tableSettings")}
                  </div>
                  <div className="flex items-center justify-between">
                    <span style={{ fontFamily: BODY, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "rgba(233,230,223,.35)" }}>
                      {t("winsTo")}
                    </span>
                    <div
                      className="flex items-center"
                      style={{
                        borderRadius: 10,
                        border: `1px solid ${C.line}`,
                        background: "rgba(0,0,0,.4)",
                        overflow: "hidden",
                      }}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          const i = MATCH_OPTIONS.indexOf(matchTo);
                          setMatchTo(MATCH_OPTIONS[Math.max(0, (i < 0 ? 0 : i) - 1)]);
                        }}
                        style={{
                          width: 34,
                          height: 32,
                          fontFamily: BODY,
                          fontSize: 15,
                          fontWeight: 700,
                          color: C.chalk,
                          background: "transparent",
                          border: "none",
                        }}
                      >
                        −
                      </button>
                      <span
                        style={{
                          width: 36,
                          textAlign: "center",
                          fontFamily: BODY,
                          fontSize: 13,
                          fontWeight: 700,
                          color: C.chalk,
                          borderLeft: `1px solid ${C.line}`,
                          borderRight: `1px solid ${C.line}`,
                          lineHeight: "32px",
                        }}
                      >
                        {matchTo}
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          const i = MATCH_OPTIONS.indexOf(matchTo);
                          setMatchTo(MATCH_OPTIONS[Math.min(MATCH_OPTIONS.length - 1, (i < 0 ? 0 : i) + 1)]);
                        }}
                        style={{
                          width: 34,
                          height: 32,
                          fontFamily: BODY,
                          fontSize: 15,
                          fontWeight: 700,
                          color: C.chalk,
                          background: "transparent",
                          border: "none",
                        }}
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <OptRow
                    label={t("pointsTo")}
                    value={target}
                    onChange={setTarget}
                    options={[
                      [21, "21"],
                      [51, "51"],
                      [101, "101"],
                    ]}
                  />
                  <div>
                    <div style={{ fontFamily: BODY, fontSize: 10, letterSpacing: 2, textTransform: "uppercase", color: "rgba(233,230,223,.35)", marginBottom: 6 }}>
                      {t("gameType")}
                    </div>
              <div className="flex" style={{ gap: 6 }}>
                {[
                  ["2x2", t("table22")],
                  ["heads", t("tableHeads")],
                  ["three", t("tableThree")],
                ].map(([v, l]) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setClubKind(v)}
                    className="flex-1 rounded-lg"
                    style={{
                      fontFamily: BODY,
                      fontSize: 12,
                      fontWeight: 700,
                      padding: "6px 0",
                      minHeight: 36,
                      color: clubKind === v ? C.night : C.chalk,
                      border: `1px solid ${clubKind === v ? C.brass : C.line}`,
                      background: clubKind === v ? C.brass : "rgba(0,0,0,.22)",
                    }}
                  >
                    {l}
                  </button>
                ))}
              </div>
                  </div>
                </div>
              )}
              {flyRoom && (() => {
                const dx = flyRoom.x1 - flyRoom.x0;
                const dy = flyRoom.y1 - flyRoom.y0;
                const ang = (Math.atan2(dy, dx) * 180) / Math.PI;
                return (
                  <>
                    {Array.from({ length: 10 }, (_, i) => {
                      const t = (i + 1) / 11;
                      return (
                        <span
                          key={i}
                          style={{
                            position: "fixed",
                            left: flyRoom.x0 + dx * t,
                            top: flyRoom.y0 + dy * t,
                            width: 9 - i * 0.45,
                            height: 9 - i * 0.45,
                            marginLeft: -4,
                            marginTop: -4,
                            borderRadius: 99,
                            background: i < 3 ? "#F6E2A8" : C.brass,
                            zIndex: 89,
                            pointerEvents: "none",
                            opacity: 0,
                            animation: `cometSpark .7s ${i * 0.055}s ease-out forwards`,
                          }}
                        />
                      );
                    })}
                    <div
                      style={{
                        position: "fixed",
                        left: flyRoom.x0,
                        top: flyRoom.y0,
                        zIndex: 90,
                        pointerEvents: "none",
                        animation: "cometFly .9s cubic-bezier(.2,.75,.2,1) forwards",
                        "--dx": `${dx}px`,
                        "--dy": `${dy}px`,
                      }}
                    >
                      <div
                        style={{
                          position: "absolute",
                          right: 14,
                          top: 6,
                          width: 96,
                          height: 12,
                          borderRadius: 99,
                          background: "linear-gradient(90deg,transparent 0%,rgba(212,168,83,.2) 30%,rgba(228,190,106,.9) 82%,#fff 100%)",
                          filter: "blur(1px)",
                          transform: `rotate(${ang + 180}deg)`,
                          transformOrigin: "right center",
                        }}
                      />
                      <svg width="28" height="28" viewBox="0 0 24 24" style={{ display: "block", marginLeft: -14, marginTop: -14, filter: "drop-shadow(0 0 12px rgba(228,190,106,1))" }}>
                        <path fill="#E8C56A" d="M12 2.2l2.7 6.6 7.1.58-5.4 4.62 1.66 6.95L12 17.4 5.94 20.95l1.66-6.95-5.4-4.62 7.1-.58z" />
                      </svg>
                    </div>
                  </>
                );
              })()}
              {clubBoard}
            </>
          )}

          <button
            onClick={() => {
              if (clubTable || roomWait) {
                leaveClubTable();
                return;
              }
              if (clubGate && !room) {
                setClubGate(null);
                return;
              }
              setRoom(null);
              setClubGate(null);
              setScreen("menu");
            }}
            style={{ fontFamily: BODY, fontSize: 13, color: "rgba(233,230,223,.45)", padding: "10px 0 6px" }}
          >
            {t("back")}
          </button>
        </div>
        {adminLayer}
      </Shell>
    );
  
}
